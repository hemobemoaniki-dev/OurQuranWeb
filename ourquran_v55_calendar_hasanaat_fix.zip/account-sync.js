/* OurQuran V41 — Firebase Authentication + Cloud Firestore. No Supabase. */
(async()=>{
  const cfg=window.OURQURAN_CONFIG||{};
  const firebaseCfg=cfg.firebase||{};
  const SITE=String(cfg.publicSiteUrl||"https://ourquran.netlify.app/");
  const SDK="12.19.0";

  const GUEST_KEY="ourQuranFirebaseGuestPrefsV40";
  const ACCOUNT_PREFIX="ourQuranFirebaseAccountV40:";
  const META_PREFIX="ourQuranFirebaseMetaV40:";
  const BASE_PREFIX="ourQuranFirebaseBaseV40:";
  const SYNC_DELAY=700;

  let auth=null,db=null,fbApp=null;
  let user=null;
  let syncTimer=null;
  let syncing=false;
  let pendingSync=false;
  let authReady=false;
  let manualAuthFlow=false;
  let lastCloudAt=null;
  let firebaseModules=null;
  let firebaseInitPromise=null;
  let hydrating=false;
  // Temporary, in-memory credentials used only to link Google and OurQuran
  // email/password sign-in to one Firebase UID. Never persisted to storage.
  let pendingGoogleCredential=null;
  let pendingGoogleEmail="";
  let pendingPasswordCredential=null;
  let pendingPasswordEmail="";

  const originalSaveState=saveState;
  const originalRenderProfile=renderProfile;

  const by=id=>document.getElementById(id);
  const ui={
    accountCard:by("oq25AccountCard"), title:by("oq25AccountTitle"), text:by("oq25AccountText"), lastSync:by("oq25LastSync"), sync:by("oq25SyncStatus"), open:by("oq25OpenAuthBtn"), out:by("oq25SignOutBtn"),
    modal:by("oq25AuthModal"), overlay:by("oq25AuthOverlay"), close:by("oq25CloseAuthBtn"), tabs:by("oq25AuthTabs"),
    signInPanel:by("oq25SignInPanel"), signUpPanel:by("oq25SignUpPanel"), resetPanel:by("oq25ResetPanel"), changePasswordPanel:by("oq35ChangePasswordPanel"),
    signInForm:by("oq25SignInForm"), signInEmail:by("oq25SignInEmail"), signInPassword:by("oq25SignInPassword"), signInStatus:by("oq25SignInStatus"),
    signUpForm:by("oq25SignUpForm"), signUpFullName:by("oq25SignUpFullName"), signUpUsername:by("oq25SignUpUsername"), signUpEmail:by("oq25SignUpEmail"), signUpPassword:by("oq25SignUpPassword"), signUpStatus:by("oq25SignUpStatus"),
    googleSignIn:by("oq40GoogleSignInBtn"), googleSignUp:by("oq40GoogleSignUpBtn"),
    forgot:by("oq25ForgotBtn"), back:by("oq25BackBtn"), resetForm:by("oq25ResetForm"), resetEmail:by("oq25ResetEmail"), resetStatus:by("oq25ResetStatus"),
    changePasswordBack:by("oq35ChangePasswordBackBtn"), changePasswordForm:by("oq35ChangePasswordForm"), currentPassword:by("oq35CurrentPassword"), newPassword:by("oq35NewPassword"), confirmPassword:by("oq35ConfirmPassword"), changePasswordStatus:by("oq35ChangePasswordStatus"), forgotCurrentPassword:by("oq35ForgotCurrentPasswordBtn"),
    guestModal:by("guestWelcomeModal"), guestOverlay:by("guestWelcomeOverlay"), guestLogin:by("guestWelcomeLogin"), guestSignup:by("guestWelcomeSignup"), guestDismiss:by("guestWelcomeDismiss"),
    syncBubble:by("guestUnsavedBubble"), syncBubbleTitle:by("oq38SyncBubbleTitle"), syncBubbleText:by("oq38SyncBubbleText"), syncBubbleArrow:by("oq38SyncBubbleArrow"),
    securityCard:by("oq37SecurityCard"), securityEmail:by("oq37SecurityEmail"),
    inlineChangeForm:by("oq37InlineChangePasswordForm"), inlineCurrentPassword:by("oq37InlineCurrentPassword"), inlineNewPassword:by("oq37InlineNewPassword"), inlineConfirmPassword:by("oq37InlineConfirmPassword"), inlineChangeStatus:by("oq37InlineChangeStatus"),
    inlineRecoveryForm:by("oq37InlineRecoveryForm"), inlineRecoveryEmail:by("oq37InlineRecoveryEmail"), inlineRecoveryStatus:by("oq37InlineRecoveryStatus")
  };

  const clone=v=>JSON.parse(JSON.stringify(v));
  const cleanUsername=value=>String(value||"").toLowerCase().replace(/^@+/,"").replace(/[^a-z0-9_]/g,"").slice(0,20);
  const configured=()=>Boolean(
    firebaseCfg.apiKey && !String(firebaseCfg.apiKey).startsWith("PASTE_") &&
    firebaseCfg.authDomain && !String(firebaseCfg.authDomain).startsWith("PASTE_") &&
    firebaseCfg.projectId && !String(firebaseCfg.projectId).startsWith("PASTE_") &&
    firebaseCfg.appId && !String(firebaseCfg.appId).startsWith("PASTE_")
  );
  const accountKey=uid=>ACCOUNT_PREFIX+uid;
  const metaKey=uid=>META_PREFIX+uid;
  const baseKey=uid=>BASE_PREFIX+uid;
  const newMutationId=()=>globalThis.crypto?.randomUUID?.()||`${Date.now()}-${Math.random().toString(36).slice(2)}`;
  const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);

  function setStatus(el,msg,kind=""){
    if(!el)return;
    el.textContent=msg||"";
    el.dataset.kind=kind||"";
  }

  function normalize(raw={}){
    const next={
      ...deepDefaultState(),...(raw||{}),
      history:raw?.history||{},
      adhkarProgress:raw?.adhkarProgress||{},
      tasbeeh:{...defaultState.tasbeeh,...(raw?.tasbeeh||{})},
      profile:{fullName:"",...defaultState.profile,...(raw?.profile||{})},
      friends:[],incomingInvite:null,
      migrations:{...(raw?.migrations||{})},
      timeTracking:{...defaultState.timeTracking,...(raw?.timeTracking||{})},
      settings:{...defaultState.settings,...(raw?.settings||{})}
    };
    if(next.settings.textSize==="comfortable")next.settings.textSize="standard";
    if(!["standard","large","xlarge"].includes(next.settings.textSize))next.settings.textSize="standard";
    if(!["kaaba","sunset","dark","light"].includes(next.settings.theme))next.settings.theme="kaaba";
    if(RECITER_ID_MIGRATIONS[next.settings.reciter])next.settings.reciter=RECITER_ID_MIGRATIONS[next.settings.reciter];
    if(!RECITERS.some(r=>r.id===next.settings.reciter))next.settings.reciter="mishary-alafasy";
    for(const rec of Object.values(next.history)){
      rec.hasanaat=Math.max(0,Number(rec.hasanaat||0));
      rec.ayat=Math.max(0,Number(rec.ayat||0));
      rec.seconds=Math.max(0,Number(rec.seconds||0));
    }
    return next;
  }

  function storedState(key){
    try{const raw=localStorage.getItem(key);return raw?normalize(JSON.parse(raw)):null;}catch{return null;}
  }
  function storedJson(key,fallback={}){
    try{return JSON.parse(localStorage.getItem(key)||"null")||fallback;}catch{return fallback;}
  }

  function neutralGuestState(raw){
    const next=normalize(raw||{});
    // Guest metrics stay device/session-only, but the reading position is a
    // harmless local preference and must survive refreshes so “Continue”
    // really returns to the last Surah/Ayah even without an account.
    next.surah=Math.max(1,Math.min(114,Number(next.surah)||1));
    next.ayah=Math.max(1,Number(next.ayah)||1);
    next.history={};next.totalHasanaat=0;next.completedReads=0;next.totalSeconds=0;
    next.adhkarProgress={};next.tasbeeh={...defaultState.tasbeeh};next.timeTracking={...defaultState.timeTracking};
    next.profile={...next.profile,fullName:"",displayName:"Reader",username:"",bio:"",avatarDataUrl:"",joinedAt:""};
    next.migrations={...(next.migrations||{}),guestSessionOnly:true};
    return next;
  }

  function persistGuestPreferences(){
    const clean=neutralGuestState(state);
    try{
      localStorage.setItem(GUEST_KEY,JSON.stringify(clean));
      localStorage.setItem(STORAGE_KEY,JSON.stringify(clean));
    }catch{}
  }

  function guestSeedSnapshot(){
    // Used only when a guest deliberately CREATES a new account. This transfers
    // their current in-memory session into the brand-new account once.
    window.ourQuranCommitActiveTime?.();
    const seed=normalize(clone(state));
    seed.profile={...seed.profile};
    seed.timeTracking={...seed.timeTracking,sessionSeconds:0,sessionStartedAt:0,lastActiveAt:0};
    seed.friends=[];seed.incomingInvite=null;
    return seed;
  }

  function getMeta(uid){return {dirty:false,baseRevision:0,mutationId:null,...storedJson(metaKey(uid),{})};}
  function setMeta(uid,meta){localStorage.setItem(metaKey(uid),JSON.stringify(meta));}
  function getBase(uid){return storedState(baseKey(uid));}
  function setBase(uid,s){localStorage.setItem(baseKey(uid),JSON.stringify(normalize(s)));}

  function resetTransientSession(target){
    const next=normalize(target);
    next.timeTracking={...next.timeTracking,sessionSeconds:0,sessionStartedAt:Date.now(),lastActiveAt:Date.now()};
    return next;
  }

  function cloudSnapshot(source=state,{commitActive=true}={}){
    // Commit active reading time only when snapshotting the live global state.
    // Serializing an already-built state must be side-effect free.
    if(commitActive && source===state) window.ourQuranCommitActiveTime?.();
    const s=normalize(clone(source));
    s.friends=[];s.incomingInvite=null;
    s.timeTracking={...s.timeTracking,sessionSeconds:0,sessionStartedAt:0,lastActiveAt:0};
    return s;
  }

  function mergeHistory(base,local,remote){
    const out={};
    const keys=new Set([...Object.keys(base?.history||{}),...Object.keys(local?.history||{}),...Object.keys(remote?.history||{})]);
    for(const key of keys){
      const b=base?.history?.[key]||{},l=local?.history?.[key]||{},r=remote?.history?.[key]||{};
      out[key]={
        hasanaat:Math.max(0,Number(r.hasanaat||0)+Math.max(0,Number(l.hasanaat||0)-Number(b.hasanaat||0))),
        ayat:Math.max(0,Number(r.ayat||0)+Math.max(0,Number(l.ayat||0)-Number(b.ayat||0))),
        seconds:Math.max(0,Number(r.seconds||0)+Math.max(0,Number(l.seconds||0)-Number(b.seconds||0)))
      };
    }
    return out;
  }

  function mergeConcurrent(base,local,remote){
    const merged=normalize(clone(remote||{}));
    merged.history=mergeHistory(base,local,remote);
    for(const key of ["settings","profile","adhkarProgress","tasbeeh"]){
      if(!same(local?.[key],base?.[key]))merged[key]=clone(local[key]);
    }
    if(Number(local?.surah)!==Number(base?.surah)||Number(local?.ayah)!==Number(base?.ayah)){
      merged.surah=Number(local.surah)||1;merged.ayah=Number(local.ayah)||1;
    }
    merged.migrations={...(remote?.migrations||{}),...(local?.migrations||{})};
    return normalize(merged);
  }

  function refreshUI({full=true}={}){
    ensureHistoryDay();
    syncDerivedTotalsFromHistory();

    // A full refresh is only needed when auth/state is initially hydrated. Routine
    // Firestore autosaves must NOT re-apply the theme or reload the Qur'an reader;
    // doing that on every write created the visible theme flicker and a save loop.
    if(full){
      populateReciters();
      hydrateSettingsUI();
    }

    renderStats();
    renderSettingSummary();
    renderDashboard();
    originalRenderProfile();
    renderAdhkar();
    renderTasbeeh();
    updateAccountUI();

    if(full&&surahs.length&&currentViewId==="readerView"){
      loadSurah(Number(state.surah)||1,Number(state.ayah)||1,false).catch(()=>{});
    }
  }

  function syncStatus(kind,label){
    if(ui.sync){ui.sync.dataset.state=kind;ui.sync.textContent=label;}
    if(ui.syncBubble){
      ui.syncBubble.hidden=false;
      const signed=!!user;
      // Routine background writes used to flip this badge between “Syncing” and
      // “Synced” every few seconds. Keep the left indicator visually steady.
      const backgroundSync=signed&&kind==="syncing"&&!!lastCloudAt;
      const visualKind=backgroundSync?"synced":kind;
      ui.syncBubble.dataset.state=visualKind;
      let title=kind==="syncing"?"Syncing…":kind==="synced"?"Synced":kind==="error"?"Sync issue":"Not syncing";
      let detail=kind==="syncing"?"Saving progress":kind==="synced"?"Auto-save on":kind==="error"?"Account connection needs attention":"Sign in / Sign up";
      if(backgroundSync){title="Synced";detail="Auto-save on";}
      if(ui.syncBubbleTitle)ui.syncBubbleTitle.textContent=title;
      if(ui.syncBubbleText)ui.syncBubbleText.textContent=detail;
      if(ui.syncBubbleArrow)ui.syncBubbleArrow.textContent=signed?"✓":"→";
    }
  }

  function hasPasswordProvider(){return !!user?.providerData?.some(p=>p.providerId==="password");}

  function updateAccountUI(){
    const signed=!!user;
    const previous=window.OURQURAN_SIGNED_IN===true;
    document.body.dataset.authState=signed?"signed-in":"guest";
    document.documentElement.dataset.authState=signed?"signed-in":"guest";
    window.OURQURAN_SIGNED_IN=signed;
    if(previous!==signed)window.ourQuranResetTrackingClock?.();

    if(ui.accountCard)ui.accountCard.hidden=signed;
    if(ui.securityCard)ui.securityCard.hidden=!signed;
    if(ui.open)ui.open.hidden=signed;
    if(ui.out){ui.out.hidden=!signed;ui.out.style.display=signed?"flex":"none";}
    if(els.resetBtn)els.resetBtn.style.display="flex";

    if(!signed){
      syncStatus("guest","Not syncing");
    }else if(ui.sync?.dataset.state!=="syncing"&&ui.sync?.dataset.state!=="error"){
      syncStatus("synced","Synced");
    }

    if(ui.title)ui.title.textContent=signed?"Signed in — cloud sync is active.":"Sign in to save and sync your progress.";
    if(ui.text){ui.text.hidden=!signed;ui.text.textContent=signed?(user.email||"Signed-in account"):"";}
    if(ui.lastSync){
      ui.lastSync.hidden=!signed;
      if(signed){
        const where=`Surah ${Number(state.surah)||1}, Ayah ${Number(state.ayah)||1}`;
        const when=lastCloudAt?`Last synced ${lastCloudAt.toLocaleTimeString([], {hour:"numeric",minute:"2-digit"})}`:"Firebase connected";
        ui.lastSync.textContent=`${when} • Continue from ${where}`;
      }
    }

    const passwordAccount=signed&&hasPasswordProvider();
    const googleAccount=!!user?.providerData?.some(p=>p.providerId==="google.com");
    if(ui.inlineChangeForm)ui.inlineChangeForm.hidden=!passwordAccount;
    if(ui.inlineRecoveryForm)ui.inlineRecoveryForm.hidden=!passwordAccount;
    if(ui.securityCard){
      ui.securityCard.dataset.accountKind=passwordAccount?(googleAccount?"linked":"password"):(signed?"google":"guest");
    }
    const securityCopy=ui.securityCard?.querySelector(".oq37-security-head p");
    if(securityCopy){
      securityCopy.textContent=passwordAccount&&googleAccount
        ? "Google and OurQuran login are connected to this same account."
        : passwordAccount
          ? "Manage your password and account recovery."
          : signed?"Signed in with Google. Your Google account manages your password.":"";
    }
    if(ui.inlineRecoveryEmail&&signed)ui.inlineRecoveryEmail.value=user.email||"";

    if(els.profileJoined){els.profileJoined.textContent=signed?`Signed in as ${user.email||"OurQuran account"}`:"";}
  }

  function panel(name){
    const signin=name==="signin",signup=name==="signup",reset=name==="reset",change=name==="change";
    if(ui.tabs)ui.tabs.hidden=reset||change;
    if(ui.signInPanel)ui.signInPanel.hidden=!signin;
    if(ui.signUpPanel)ui.signUpPanel.hidden=!signup;
    if(ui.resetPanel)ui.resetPanel.hidden=!reset;
    if(ui.changePasswordPanel)ui.changePasswordPanel.hidden=!change;
    document.querySelectorAll("[data-oq25-tab]").forEach(b=>b.classList.toggle("active",b.dataset.oq25Tab===name));
  }
  function open(name="signin"){
    panel(name);ui.modal?.classList.add("open");ui.modal?.setAttribute("aria-hidden","false");document.body.classList.add("utility-modal-open");
  }
  function close(){
    ui.modal?.classList.remove("open");ui.modal?.setAttribute("aria-hidden","true");
    if(!document.querySelector(".utility-modal.open"))document.body.classList.remove("utility-modal-open");
  }

  let guestPromptHandled=false;
  function openGuestWelcome(){
    if(!ui.guestModal||user||guestPromptHandled||!authReady)return;
    ui.guestModal.classList.add("open");ui.guestModal.setAttribute("aria-hidden","false");document.body.classList.add("utility-modal-open");
  }
  function closeGuestWelcome(){
    guestPromptHandled=true;ui.guestModal?.classList.remove("open");ui.guestModal?.setAttribute("aria-hidden","true");
    if(!document.querySelector(".utility-modal.open"))document.body.classList.remove("utility-modal-open");
  }

  function firebaseError(err){
    const code=String(err?.code||"");
    const map={
      "auth/invalid-credential":"Email or password is incorrect.",
      "auth/wrong-password":"Current password is incorrect.",
      "auth/email-already-in-use":"An account already uses that email.",
      "auth/account-exists-with-different-credential":"That email already has an OurQuran account. Sign in with the existing method once so both logins can be connected.",
      "auth/credential-already-in-use":"That sign-in method is already connected to another account.",
      "auth/invalid-email":"Enter a valid email address.",
      "auth/weak-password":"Choose a stronger password.",
      "auth/popup-closed-by-user":"Google sign-in was closed before it finished.",
      "auth/popup-blocked":"Your browser blocked the Google sign-in window.",
      "auth/unauthorized-domain":"Add this site to Firebase Authentication → Authorized domains.",
      "auth/network-request-failed":"Network error. Check your connection and try again.",
      "auth/operation-not-allowed":"Enable this sign-in method in Firebase Authentication.",
      "permission-denied":"Firestore blocked the request. Check your Firestore security rules.",
      "ourquran/username-taken":"That username is already taken."
    };
    return map[code]||err?.message||"Something went wrong.";
  }

  async function loadFirebase(){
    if(!configured())throw new Error("Firebase is not configured yet. Paste your Web App config into site-config.js.");
    const [appMod,authMod,firestoreMod]=await Promise.all([
      import(`https://www.gstatic.com/firebasejs/${SDK}/firebase-app.js`),
      import(`https://www.gstatic.com/firebasejs/${SDK}/firebase-auth.js`),
      import(`https://www.gstatic.com/firebasejs/${SDK}/firebase-firestore.js`)
    ]);
    firebaseModules={appMod,authMod,firestoreMod};
    fbApp=appMod.initializeApp(firebaseCfg);
    auth=authMod.getAuth(fbApp);
    await authMod.setPersistence(auth,authMod.browserLocalPersistence);
    authMod.useDeviceLanguage(auth);
    db=firestoreMod.getFirestore(fbApp);
  }

  async function ensureFirebaseReady(statusEl=null){
    if(firebaseModules&&auth&&db)return true;
    if(!configured()){
      const msg="Firebase is not configured yet.";
      setStatus(statusEl,msg,"error");
      showToast(msg);
      return false;
    }
    try{
      if(!firebaseInitPromise)firebaseInitPromise=loadFirebase();
      await firebaseInitPromise;
      return Boolean(firebaseModules&&auth&&db);
    }catch(err){
      firebaseInitPromise=null;
      const msg=firebaseError(err);
      setStatus(statusEl,msg,"error");
      syncStatus("error","Sync issue");
      showToast(msg);
      return false;
    }
  }

  async function reserveNewUserDocument(firebaseUser,{seed,fullName,username}={}){
    const {doc,runTransaction,serverTimestamp}=firebaseModules.firestoreMod;
    let desired=cleanUsername(username||"");
    if(desired.length<3){
      const base=cleanUsername((firebaseUser.email||"").split("@")[0]||firebaseUser.displayName||"reader").slice(0,16)||"reader";
      desired=base.length>=3?base:"reader";
    }

    const userRef=doc(db,"users",firebaseUser.uid);
    let attempt=0;
    while(attempt<12){
      const candidate=attempt===0?desired:`${desired.slice(0,15)}${Math.floor(1000+Math.random()*9000)}`.slice(0,20);
      const usernameRef=doc(db,"usernames",candidate);
      try{
        const result=await runTransaction(db,async tx=>{
          const existingUser=await tx.get(userRef);
          if(existingUser.exists())return {created:false,username:existingUser.data().username||candidate};
          const taken=await tx.get(usernameRef);
          if(taken.exists())throw Object.assign(new Error("Username already taken"),{code:"ourquran/username-taken"});

          const accountState=normalize(seed||deepDefaultState());
          const name=(fullName||firebaseUser.displayName||accountState.profile.fullName||candidate).trim().slice(0,60)||candidate;
          accountState.profile={
            ...accountState.profile,
            fullName:name,
            displayName:candidate,
            username:candidate,
            avatarDataUrl:accountState.profile.avatarDataUrl||firebaseUser.photoURL||"",
            joinedAt:accountState.profile.joinedAt||new Date().toISOString()
          };
          syncDerivedTotalsFor(accountState);
          const todayKey=localDateKey(new Date());
          const today=accountState.history?.[todayKey]||{hasanaat:0,ayat:0,seconds:0};
          tx.set(usernameRef,{uid:firebaseUser.uid,createdAt:serverTimestamp()});
          const canonical={
            schemaVersion:2,uid:firebaseUser.uid,email:firebaseUser.email||"",fullName:name,username:candidate,
            photoURL:accountState.profile.avatarDataUrl||firebaseUser.photoURL||"",
            profile:clone(accountState.profile),history:clone(accountState.history||{}),settings:clone(accountState.settings||{}),
            adhkarProgress:clone(accountState.adhkarProgress||{}),tasbeeh:clone(accountState.tasbeeh||{}),
            providers:(firebaseUser.providerData||[]).map(p=>p.providerId),
            currentSurah:Number(accountState.surah)||1,currentAyah:Number(accountState.ayah)||1,
            totalHasanaat:Number(accountState.totalHasanaat)||0,completedReads:Number(accountState.completedReads)||0,totalSeconds:Number(accountState.totalSeconds)||0,
            todayKey,todayStats:{hasanaat:Number(today.hasanaat)||0,ayat:Number(today.ayat)||0,seconds:Number(today.seconds)||0},
            appState:cloudSnapshot(accountState),revision:1,lastMutationId:newMutationId(),createdAt:serverTimestamp(),updatedAt:serverTimestamp()
          };
          tx.set(userRef,canonical);
          return {created:true,username:candidate,state:accountState,revision:1};
        });
        return result;
      }catch(err){
        if(err?.code!=="ourquran/username-taken")throw err;
        if(username&&attempt===0)throw err;
        attempt++;
      }
    }
    throw new Error("Could not create a unique username. Please choose one manually.");
  }

  function syncDerivedTotalsFor(s){
    const totals=Object.values(s.history||{}).reduce((acc,r)=>{acc.hasanaat+=Number(r.hasanaat||0);acc.ayat+=Number(r.ayat||0);acc.seconds+=Number(r.seconds||0);return acc;},{hasanaat:0,ayat:0,seconds:0});
    s.totalHasanaat=totals.hasanaat;s.completedReads=totals.ayat;s.totalSeconds=totals.seconds;return s;
  }


  // V46: appState remains backward-compatible, while the important cloud fields
  // are also stored explicitly on the user document. Hydration rebuilds from
  // those canonical fields when present so profile/progress cannot silently fall
  // back to an older Google/default identity after a new login.
  function stateFromRemote(remote={}){
    const next=normalize(remote.appState||{});
    if(remote.history && typeof remote.history==="object") next.history=clone(remote.history);
    if(remote.settings && typeof remote.settings==="object") next.settings={...next.settings,...clone(remote.settings)};
    if(remote.adhkarProgress && typeof remote.adhkarProgress==="object") next.adhkarProgress=clone(remote.adhkarProgress);
    if(remote.tasbeeh && typeof remote.tasbeeh==="object") next.tasbeeh={...next.tasbeeh,...clone(remote.tasbeeh)};
    if(remote.profile && typeof remote.profile==="object") next.profile={...next.profile,...clone(remote.profile)};
    if(Number(remote.currentSurah)>0) next.surah=Number(remote.currentSurah);
    if(Number(remote.currentAyah)>0) next.ayah=Number(remote.currentAyah);
    syncDerivedTotalsFor(next);
    return normalize(next);
  }

  function cloudFields(next,extra={}){
    syncDerivedTotalsFor(next);
    const todayKey=localDateKey(new Date());
    const today=next.history?.[todayKey]||{hasanaat:0,ayat:0,seconds:0};
    const compactAppState=cloudSnapshot(next,{commitActive:false});
    // Keep the custom image in exactly one Firestore field. This avoids tripling a
    // base64 avatar inside the same 1 MiB user document while retaining legacy appState.
    if(compactAppState.profile) compactAppState.profile.avatarDataUrl="";
    return {
      schemaVersion:2,
      uid:user?.uid||extra.uid||"",
      email:user?.email||extra.email||"",
      fullName:next.profile.fullName||user?.displayName||"",
      username:cleanUsername(next.profile.username)||extra.username||"",
      photoURL:next.profile.avatarDataUrl||user?.photoURL||extra.photoURL||"",
      profile:clone(next.profile),
      history:clone(next.history||{}),
      settings:clone(next.settings||{}),
      adhkarProgress:clone(next.adhkarProgress||{}),
      tasbeeh:clone(next.tasbeeh||{}),
      providers:(user?.providerData||[]).map(p=>p.providerId),
      currentSurah:Number(next.surah)||1,
      currentAyah:Number(next.ayah)||1,
      totalHasanaat:Number(next.totalHasanaat)||0,
      completedReads:Number(next.completedReads)||0,
      totalSeconds:Number(next.totalSeconds)||0,
      todayKey,
      todayStats:{hasanaat:Number(today.hasanaat)||0,ayat:Number(today.ayat)||0,seconds:Number(today.seconds)||0},
      appState:compactAppState
    };
  }


  function hasGuestSessionProgress(seed){
    if(!seed)return false;
    const history=Object.values(seed.history||{});
    const totals=history.reduce((acc,r)=>{
      acc.hasanaat+=Math.max(0,Number(r?.hasanaat||0));
      acc.ayat+=Math.max(0,Number(r?.ayat||0));
      acc.seconds+=Math.max(0,Number(r?.seconds||0));
      return acc;
    },{hasanaat:0,ayat:0,seconds:0});
    return totals.hasanaat>0||totals.ayat>0||totals.seconds>0||Number(seed.surah)!==1||Number(seed.ayah)!==1;
  }

  function mergeGuestSessionIntoAccount(accountState,guestSeed){
    const next=normalize(clone(accountState||{}));
    const guest=normalize(clone(guestSeed||{}));
    if(!hasGuestSessionProgress(guest))return {state:next,imported:false};

    for(const [key,rec] of Object.entries(guest.history||{})){
      const current=next.history[key]||{hasanaat:0,ayat:0,seconds:0};
      next.history[key]={
        hasanaat:Math.max(0,Number(current.hasanaat||0))+Math.max(0,Number(rec.hasanaat||0)),
        ayat:Math.max(0,Number(current.ayat||0))+Math.max(0,Number(rec.ayat||0)),
        seconds:Math.max(0,Number(current.seconds||0))+Math.max(0,Number(rec.seconds||0))
      };
    }

    // If the reader actually read/navigated as a guest, continue exactly where
    // that session stopped. Time-only activity on Home/Profile should not reset an
    // established cloud reading position back to Al-Fatihah 1:1.
    const guestTotals=Object.values(guest.history||{}).reduce((acc,r)=>{
      acc.hasanaat+=Math.max(0,Number(r?.hasanaat||0));
      acc.ayat+=Math.max(0,Number(r?.ayat||0));
      return acc;
    },{hasanaat:0,ayat:0});
    const guestMoved=Number(guest.surah)!==1||Number(guest.ayah)!==1||guestTotals.hasanaat>0||guestTotals.ayat>0;
    if(guestMoved){
      next.surah=Math.max(1,Number(guest.surah)||1);
      next.ayah=Math.max(1,Number(guest.ayah)||1);
    }
    syncDerivedTotalsFor(next);
    return {state:next,imported:true};
  }

  function applyAuthIdentity(target,remote,firebaseUser){
    const next=target;
    next.profile={...defaultState.profile,...(next.profile||{})};
    let changed=false;

    const remoteUsername=cleanUsername(remote?.username||"");
    const currentUsername=cleanUsername(next.profile.username||"");
    const missingUsername=!currentUsername||currentUsername==="reader";
    if(missingUsername&&remoteUsername&&remoteUsername!=="reader"){
      next.profile.username=remoteUsername;
      next.profile.displayName=remoteUsername;
      changed=true;
    }

    const authName=String(remote?.fullName||firebaseUser?.displayName||"").trim().slice(0,60);
    const currentName=String(next.profile.fullName||"").trim();
    if(authName&&(!currentName||currentName.toLowerCase()==="reader")){
      next.profile.fullName=authName;
      changed=true;
    }

    const authPhoto=String(remote?.photoURL||firebaseUser?.photoURL||"").trim();
    if(authPhoto&&!String(next.profile.avatarDataUrl||"").trim()){
      next.profile.avatarDataUrl=authPhoto;
      changed=true;
    }

    if(!next.profile.joinedAt){
      const created=firebaseUser?.metadata?.creationTime;
      next.profile.joinedAt=created?new Date(created).toISOString():new Date().toISOString();
      changed=true;
    }

    return changed;
  }

  async function fetchRemote(uid){
    const {doc,getDocFromServer,getDoc}=firebaseModules.firestoreMod;
    const ref=doc(db,"users",uid);
    try{return await getDocFromServer(ref);}catch{return await getDoc(ref);}
  }

  function exposeSignedIn(firebaseUser){
    user=firebaseUser;
    document.body.dataset.authState="signed-in";
    document.documentElement.dataset.authState="signed-in";
    window.OURQURAN_SIGNED_IN=true;
    closeGuestWelcome();
  }

  // Make authentication feel immediate: as soon as Firebase Auth succeeds, render the
  // last locally cached account state and let the authoritative Firestore hydration run
  // in the background. The cache is only presentation; hydrate() still reconciles against
  // the server before any cloud write is allowed.
  function primeSignedInUI(firebaseUser,{fallback=null}={}){
    exposeSignedIn(firebaseUser);
    const cached=storedState(accountKey(firebaseUser.uid));
    if(cached){
      state=resetTransientSession(cached);
    }else if(fallback){
      state=resetTransientSession(normalize(fallback));
    }
    syncStatus("syncing",cached?"Refreshing…":"Loading…");
    refreshUI();
    updateAccountUI();
    return Boolean(cached);
  }

  async function hydrate(firebaseUser,{seedIfMissing=null,guestSeed=null}={}){
    exposeSignedIn(firebaseUser);
    syncStatus("syncing","Loading…");hydrating=true;
    try{
      let snap=await fetchRemote(firebaseUser.uid);
      if(!snap.exists()){
        await reserveNewUserDocument(firebaseUser,{seed:seedIfMissing||deepDefaultState()});
        snap=await fetchRemote(firebaseUser.uid);
      }
      const remote=snap.data()||{};
      const remoteState=stateFromRemote(remote);
      const remoteRevision=Number(remote.revision||0);
      const local=storedState(accountKey(firebaseUser.uid));
      const meta=getMeta(firebaseUser.uid);
      let chosen=remoteState;
      let shouldPush=false;

      // Only prefer device state when it is explicitly marked unsynced. This preserves
      // offline edits without letting an old cache overwrite a successfully synced account.
      if(local&&meta.dirty){
        chosen=normalize(local);
        shouldPush=true;
      }

      if(guestSeed&&hasGuestSessionProgress(guestSeed)){
        const merged=mergeGuestSessionIntoAccount(chosen,guestSeed);
        chosen=merged.state;
        shouldPush=shouldPush||merged.imported;
      }

      if(applyAuthIdentity(chosen,remote,firebaseUser))shouldPush=true;

      state=resetTransientSession(chosen);
      localStorage.setItem(accountKey(firebaseUser.uid),JSON.stringify(state));
      setBase(firebaseUser.uid,remoteState);
      setMeta(firebaseUser.uid,{dirty:shouldPush,baseRevision:remoteRevision,mutationId:meta.mutationId||null});
      lastCloudAt=remote.updatedAt?.toDate?.()||new Date();
      refreshUI();
    }catch(err){
      console.error("Firebase hydrate failed",err);
      const cached=storedState(accountKey(firebaseUser.uid));
      if(cached){state=resetTransientSession(cached);refreshUI();}
      syncStatus("error","Sync issue");
      showToast(firebaseError(err));
      hydrating=false;
      updateAccountUI();
      return;
    }
    hydrating=false;
    const meta=getMeta(firebaseUser.uid);
    if(meta.dirty){
      // Do not make sign-in/navigation wait for a Firestore transaction. The local state
      // is already safely persisted; reconcile it in the background and keep the UI live.
      syncStatus("syncing","Syncing…");
      Promise.resolve().then(()=>flush({force:true})).catch(err=>{
        console.error("Background Firebase sync failed",err);
        syncStatus("error","Sync issue");
      });
    }else{
      syncStatus("synced","Synced");
    }
    updateAccountUI();
  }

  function storeAccountDirty(){
    if(!user)return;
    const meta=getMeta(user.uid);
    meta.dirty=true;meta.mutationId=newMutationId();
    setMeta(user.uid,meta);
    localStorage.setItem(accountKey(user.uid),JSON.stringify(state));
  }

  async function flush({force=false}={}){
    if(!user||!firebaseModules||hydrating)return;
    if(syncing){
      pendingSync=true;
      if(force){
        while(syncing) await new Promise(resolve=>setTimeout(resolve,40));
        if(pendingSync) return flush({force:false});
      }
      return;
    }
    syncing=true;pendingSync=false;clearTimeout(syncTimer);syncTimer=null;
    window.ourQuranCommitActiveTime?.();
    storeAccountDirty();
    syncStatus("syncing","Syncing…");
    try{
      const local=cloudSnapshot(state,{commitActive:false});
      const meta=getMeta(user.uid);
      const base=getBase(user.uid)||normalize(clone(local));
      const mutationId=meta.mutationId||newMutationId();
      const {doc,runTransaction,serverTimestamp}=firebaseModules.firestoreMod;
      const ref=doc(db,"users",user.uid);
      let committedState=local;
      let committedRevision=Math.max(0,Number(meta.baseRevision||0))+1;

      // Atomic merge: if another device wrote since this device last hydrated,
      // merge only this device's history delta into the newest cloud history.
      // That prevents lost hasanaat/ayat and keeps streaks accurate across devices,
      // while local profile/settings edits still win only when they actually changed.
      await runTransaction(db,async tx=>{
        const snap=await tx.get(ref);
        const remote=snap.exists()?(snap.data()||{}):{};
        const remoteRevision=Math.max(0,Number(remote.revision||0));
        const remoteState=snap.exists()?stateFromRemote(remote):deepDefaultState();
        let candidate=local;
        if(snap.exists()&&remoteRevision>Number(meta.baseRevision||0)){
          candidate=mergeConcurrent(base,local,remoteState);
        }
        syncDerivedTotalsFor(candidate);
        committedState=normalize(clone(candidate));
        committedRevision=remoteRevision+1;
        tx.set(ref,{
          ...cloudFields(committedState,{username:committedState.profile?.username||""}),
          revision:committedRevision,lastMutationId:mutationId,updatedAt:serverTimestamp()
        },{merge:true});
      });

      const latestMeta=getMeta(user.uid);
      const changedDuringSync=!!latestMeta.mutationId&&latestMeta.mutationId!==mutationId;
      setBase(user.uid,committedState);
      lastCloudAt=new Date();

      if(changedDuringSync){
        // The reader advanced again while this Firestore transaction was in flight.
        // Keep those newer in-memory/local edits and immediately queue another merge.
        setMeta(user.uid,{...latestMeta,dirty:true,baseRevision:committedRevision});
        pendingSync=true;
        syncStatus("syncing","Syncing…");
      }else{
        state=resetTransientSession(committedState);
        localStorage.setItem(accountKey(user.uid),JSON.stringify(state));
        setMeta(user.uid,{dirty:false,baseRevision:committedRevision,mutationId});
        syncStatus("synced","Synced");
        refreshUI({full:false});
      }
    }catch(err){
      console.error("Firebase save failed",err);
      pendingSync=true;
      syncStatus("error","Sync issue");
      showToast(firebaseError(err));
    }finally{
      syncing=false;
      if(pendingSync&&!syncTimer)schedule(1800);
    }
  }

  function schedule(delay=SYNC_DELAY){
    if(!user)return;pendingSync=true;clearTimeout(syncTimer);syncTimer=setTimeout(()=>{syncTimer=null;flush();},delay);
  }

  saveState=function(){
    if(user){
      if(hydrating)return;
      storeAccountDirty();schedule();
    }else persistGuestPreferences();
  };
  renderProfile=function(){originalRenderProfile();updateAccountUI();};

  async function emailSignUp(){
    if(!(await ensureFirebaseReady(ui.signUpStatus)))return;
    const {createUserWithEmailAndPassword,deleteUser,EmailAuthProvider}=firebaseModules.authMod;
    const fullName=(ui.signUpFullName?.value||"").trim().slice(0,60);
    const username=cleanUsername(ui.signUpUsername?.value||"");
    const email=(ui.signUpEmail?.value||"").trim();
    const password=ui.signUpPassword?.value||"";
    if(!fullName)return setStatus(ui.signUpStatus,"Enter your name.","error");
    if(username.length<3)return setStatus(ui.signUpStatus,"Username must be at least 3 characters.","error");
    if(password.length<8)return setStatus(ui.signUpStatus,"Password must be at least 8 characters.","error");
    const seed=guestSeedSnapshot();
    manualAuthFlow=true;setStatus(ui.signUpStatus,"Creating account…");
    let created=null;
    try{
      const cred=await createUserWithEmailAndPassword(auth,email,password);created=cred.user;
      await reserveNewUserDocument(created,{seed,fullName,username});
      await hydrate(created);
      setStatus(ui.signUpStatus,"Account created and syncing.","success");close();showToast(`Welcome, ${fullName}`);
    }catch(err){
      if(created&&err?.code==="ourquran/username-taken"){try{await deleteUser(created);}catch{}}
      if(err?.code==="auth/email-already-in-use"){
        pendingPasswordCredential=EmailAuthProvider.credential(email,password);
        pendingPasswordEmail=email.toLowerCase();
        setStatus(ui.signUpStatus,"That email already has an account. If it is your Google account, tap Continue with Google once to connect this OurQuran password to the same account. Otherwise, sign in instead.","error");
      }else{
        setStatus(ui.signUpStatus,err?.code==="ourquran/username-taken"?"That username is already taken.":firebaseError(err),"error");
      }
    }finally{manualAuthFlow=false;}
  }

  async function emailSignIn(){
    if(!(await ensureFirebaseReady(ui.signInStatus)))return;
    const {signInWithEmailAndPassword,linkWithCredential}=firebaseModules.authMod;
    const email=(ui.signInEmail?.value||"").trim();const password=ui.signInPassword?.value||"";
    const seed=guestSeedSnapshot();
    manualAuthFlow=true;setStatus(ui.signInStatus,"Signing in…");
    try{
      let cred=await signInWithEmailAndPassword(auth,email,password);
      if(pendingGoogleCredential&&pendingGoogleEmail&&pendingGoogleEmail===String(cred.user.email||"").toLowerCase()){
        try{
          cred=await linkWithCredential(cred.user,pendingGoogleCredential);
          pendingGoogleCredential=null;pendingGoogleEmail="";
          showToast("Google connected to your OurQuran account");
        }catch(linkErr){
          if(linkErr?.code!=="auth/provider-already-linked")throw linkErr;
          pendingGoogleCredential=null;pendingGoogleEmail="";
        }
      }

      // Authentication is complete. Show the account immediately from local cache, close
      // the modal, then refresh the newest Firestore state without blocking the user.
      primeSignedInUI(cred.user,{fallback:seed});
      setStatus(ui.signInStatus,"Signed in — refreshing your latest progress…","success");
      close();showToast("Signed in — syncing in background");
      hydrate(cred.user,{guestSeed:seed}).catch(err=>{
        console.error("Background sign-in hydration failed",err);
      }).finally(()=>{manualAuthFlow=false;});
      return;
    }catch(err){
      manualAuthFlow=false;
      setStatus(ui.signInStatus,firebaseError(err),"error");
    }
  }

  async function googleSignIn(){
    const statusEl=ui.signUpPanel&&!ui.signUpPanel.hidden?ui.signUpStatus:ui.signInStatus;
    if(!(await ensureFirebaseReady(statusEl)))return;
    const {GoogleAuthProvider,signInWithPopup,linkWithCredential}=firebaseModules.authMod;
    const seed=guestSeedSnapshot();manualAuthFlow=true;
    const provider=new GoogleAuthProvider();
    // Do not force Google's account chooser on every login. If the browser already knows
    // the active Google account, Firebase can complete much faster; users can still choose
    // an account when Google actually needs a choice.
    setStatus(ui.signInStatus,"Opening Google sign-in…");
    setStatus(ui.signUpStatus,"Opening Google sign-in…");
    if(ui.googleSignIn)ui.googleSignIn.disabled=true;
    if(ui.googleSignUp)ui.googleSignUp.disabled=true;
    try{
      let cred=await signInWithPopup(auth,provider);
      if(pendingPasswordCredential&&pendingPasswordEmail&&pendingPasswordEmail===String(cred.user.email||"").toLowerCase()){
        try{
          cred=await linkWithCredential(cred.user,pendingPasswordCredential);
          pendingPasswordCredential=null;pendingPasswordEmail="";
          showToast("OurQuran password connected to your Google account");
        }catch(linkErr){
          if(linkErr?.code!=="auth/provider-already-linked")throw linkErr;
          pendingPasswordCredential=null;pendingPasswordEmail="";
        }
      }

      // Previous builds did an extra Firestore read here and then hydrate() immediately
      // performed another one. Remove that duplicate request and let hydrate() be the one
      // authoritative cloud read/create path.
      primeSignedInUI(cred.user,{fallback:seed});
      close();showToast("Signed in with Google — syncing in background");
      hydrate(cred.user,{seedIfMissing:seed,guestSeed:seed}).catch(err=>{
        console.error("Background Google hydration failed",err);
      }).finally(()=>{manualAuthFlow=false;});
      return;
    }catch(err){
      manualAuthFlow=false;
      if(err?.code==="auth/account-exists-with-different-credential"){
        const pending=GoogleAuthProvider.credentialFromError?.(err)||null;
        const email=String(err?.customData?.email||"").toLowerCase();
        if(pending&&email){
          pendingGoogleCredential=pending;pendingGoogleEmail=email;
          const msg="This email already has an OurQuran password. Sign in with email/password once and Google will be linked to the same account.";
          setStatus(ui.signInStatus,msg,"error");setStatus(ui.signUpStatus,msg,"error");
        }else{
          const msg=firebaseError(err);setStatus(ui.signInStatus,msg,"error");setStatus(ui.signUpStatus,msg,"error");
        }
      }else{
        const msg=firebaseError(err);setStatus(ui.signInStatus,msg,"error");setStatus(ui.signUpStatus,msg,"error");
      }
    }finally{
      if(ui.googleSignIn)ui.googleSignIn.disabled=false;
      if(ui.googleSignUp)ui.googleSignUp.disabled=false;
    }
  }

  async function sendReset(email,statusEl){
    if(!(await ensureFirebaseReady(statusEl)))return;
    const {sendPasswordResetEmail}=firebaseModules.authMod;
    if(!email)return setStatus(statusEl,"Enter your account email.","error");
    setStatus(statusEl,"Sending reset email…");
    try{
      await sendPasswordResetEmail(auth,email,{url:SITE,handleCodeInApp:false});
      setStatus(statusEl,"Check your inbox. Firebase will open a secure password-reset page.","success");
    }catch(err){setStatus(statusEl,firebaseError(err),"error");}
  }

  async function changePassword(current,next,statusEl){
    if(!(await ensureFirebaseReady(statusEl)))return;
    const {EmailAuthProvider,reauthenticateWithCredential,updatePassword}=firebaseModules.authMod;
    if(!user?.email)return setStatus(statusEl,"This account signs in with Google; manage its password in Google.","error");
    const cred=EmailAuthProvider.credential(user.email,current);
    setStatus(statusEl,"Verifying current password…");
    try{await reauthenticateWithCredential(user,cred);await updatePassword(user,next);setStatus(statusEl,"Password updated.","success");showToast("Password changed successfully");}
    catch(err){setStatus(statusEl,firebaseError(err),"error");}
  }

  async function signOutNow(){
    const {signOut}=firebaseModules.authMod;
    try{if(user)await flush();}catch{}
    try{await signOut(auth);}catch(err){showToast(firebaseError(err));}
  }

  async function reserveProfileUsername(nextUsername,previousUsername){
    if(!user || !nextUsername)return {created:false};
    const {doc,runTransaction,serverTimestamp}=firebaseModules.firestoreMod;
    const ref=doc(db,"usernames",nextUsername);
    let created=false;
    await runTransaction(db,async tx=>{
      const snap=await tx.get(ref);
      if(snap.exists()&&snap.data()?.uid!==user.uid){
        throw Object.assign(new Error("Username already taken"),{code:"ourquran/username-taken"});
      }
      created=!snap.exists();
      tx.set(ref,{uid:user.uid,updatedAt:serverTimestamp()},{merge:true});
    });
    return {created};
  }

  async function releaseProfileUsername(username){
    if(!user||!username)return;
    const {doc,runTransaction}=firebaseModules.firestoreMod;
    const ref=doc(db,"usernames",username);
    await runTransaction(db,async tx=>{
      const snap=await tx.get(ref);
      if(snap.exists()&&snap.data()?.uid===user.uid)tx.delete(ref);
    });
  }

  async function saveProfile(){
    if(!user){showToast("Sign in to edit your profile");return;}
    const fullName=(els.profileFullNameInput?.value||"").trim().slice(0,60);
    const nextUsername=cleanUsername(els.profileUsernameInput?.value||"");
    const bio=(els.profileBioInput?.value||"").trim().slice(0,120);
    if(!fullName)return showToast("Enter your name");
    if(nextUsername.length<3)return showToast("Username must be at least 3 characters");
    if(!(await ensureFirebaseReady()))return;

    syncStatus("syncing","Saving profile…");
    const previousUsername=cleanUsername(state.profile?.username||"");
    let usernameClaimCreated=false;
    try{
      const claim=await reserveProfileUsername(nextUsername,previousUsername);
      usernameClaimCreated=!!claim.created;
      state.profile={...state.profile,fullName,displayName:nextUsername,username:nextUsername,bio};
      storeAccountDirty();
      localStorage.setItem(accountKey(user.uid),JSON.stringify(state));

      // Profile data rides the same canonical account write as reading progress.
      // This removes the old username-transaction failure path that could leave the
      // screen looking saved while the account document stayed stale.
      await flush({force:true});

      try{
        const {updateProfile}=firebaseModules.authMod;
        await updateProfile(user,{displayName:fullName});
      }catch{}

      const verify=await fetchRemote(user.uid);
      const verified=verify.exists()?stateFromRemote(verify.data()||{}):null;
      if(!verified || cleanUsername(verified.profile.username)!==nextUsername || String(verified.profile.bio||"")!==bio){
        throw new Error("Profile did not verify in Firestore. Please try again.");
      }
      const localAvatar=String(state.profile.avatarDataUrl||"");
      const cloudAvatar=String(verified.profile.avatarDataUrl||"");
      if(localAvatar && localAvatar!==cloudAvatar){
        throw new Error("Profile photo did not verify in Firestore. Please try again.");
      }

      state=resetTransientSession(verified);
      localStorage.setItem(accountKey(user.uid),JSON.stringify(state));
      setBase(user.uid,verified);
      const remoteRevision=Number(verify.data()?.revision||getMeta(user.uid).baseRevision||0);
      setMeta(user.uid,{dirty:false,baseRevision:remoteRevision,mutationId:getMeta(user.uid).mutationId||null});
      if(previousUsername&&previousUsername!==nextUsername){
        try{await releaseProfileUsername(previousUsername);}catch(err){console.warn("Could not release previous username",err);}
      }
      syncStatus("synced","Synced");
      window.ourQuranProfileEditorCommit?.();
      renderProfile();
      showToast("Profile saved to your account");
    }catch(err){
      if(usernameClaimCreated&&nextUsername!==previousUsername){
        try{await releaseProfileUsername(nextUsername);}catch{}
      }
      syncStatus("error","Sync issue");
      showToast(firebaseError(err));
    }
  }

  window.OURQURAN_ACCOUNT={saveProfile,flush};

  // UI events
  document.querySelectorAll("[data-oq25-tab]").forEach(b=>b.addEventListener("click",()=>panel(b.dataset.oq25Tab)));
  ui.open?.addEventListener("click",()=>open("signin"));
  ui.close?.addEventListener("click",close);ui.overlay?.addEventListener("click",close);
  ui.guestLogin?.addEventListener("click",()=>{closeGuestWelcome();open("signin");});
  ui.guestSignup?.addEventListener("click",()=>{closeGuestWelcome();open("signup");});
  ui.guestDismiss?.addEventListener("click",closeGuestWelcome);ui.guestOverlay?.addEventListener("click",closeGuestWelcome);
  ui.syncBubble?.addEventListener("click",()=>user?switchView("profileView"):open("signin"));
  ui.signInForm?.addEventListener("submit",e=>{e.preventDefault();emailSignIn();});
  ui.signUpForm?.addEventListener("submit",e=>{e.preventDefault();emailSignUp();});
  ui.signUpUsername?.addEventListener("input",e=>{e.target.value=cleanUsername(e.target.value);});
  ui.googleSignIn?.addEventListener("click",googleSignIn);ui.googleSignUp?.addEventListener("click",googleSignIn);
  ui.forgot?.addEventListener("click",()=>{if(ui.resetEmail)ui.resetEmail.value=ui.signInEmail?.value||"";panel("reset");});
  ui.back?.addEventListener("click",()=>panel("signin"));
  ui.resetForm?.addEventListener("submit",e=>{e.preventDefault();sendReset(ui.resetEmail?.value.trim()||"",ui.resetStatus);});
  ui.inlineRecoveryForm?.addEventListener("submit",e=>{e.preventDefault();sendReset(ui.inlineRecoveryEmail?.value.trim()||user?.email||"",ui.inlineRecoveryStatus);});
  ui.forgotCurrentPassword?.addEventListener("click",()=>{if(ui.resetEmail)ui.resetEmail.value=user?.email||"";panel("reset");});
  ui.changePasswordBack?.addEventListener("click",close);
  ui.changePasswordForm?.addEventListener("submit",e=>{
    e.preventDefault();const current=ui.currentPassword?.value||"",next=ui.newPassword?.value||"",confirm=ui.confirmPassword?.value||"";
    if(!current)return setStatus(ui.changePasswordStatus,"Enter your current password.","error");
    if(next.length<8)return setStatus(ui.changePasswordStatus,"New password must be at least 8 characters.","error");
    if(next!==confirm)return setStatus(ui.changePasswordStatus,"The new passwords do not match.","error");
    changePassword(current,next,ui.changePasswordStatus);
  });
  ui.inlineChangeForm?.addEventListener("submit",e=>{
    e.preventDefault();const current=ui.inlineCurrentPassword?.value||"",next=ui.inlineNewPassword?.value||"",confirm=ui.inlineConfirmPassword?.value||"";
    if(!current)return setStatus(ui.inlineChangeStatus,"Enter your current password.","error");
    if(next.length<8)return setStatus(ui.inlineChangeStatus,"New password must be at least 8 characters.","error");
    if(next===current)return setStatus(ui.inlineChangeStatus,"Choose a different password.","error");
    if(next!==confirm)return setStatus(ui.inlineChangeStatus,"The new passwords do not match.","error");
    changePassword(current,next,ui.inlineChangeStatus);
  });
  ui.out?.addEventListener("click",signOutNow);
  document.addEventListener("keydown",e=>{if(e.key==="Escape"&&ui.modal?.classList.contains("open"))close();});

  els.nextBtn?.addEventListener("click",()=>{if(user)setTimeout(flush,250);});
  document.getElementById("doneBtn")?.addEventListener("click",()=>{if(user)setTimeout(flush,0);});
  document.querySelectorAll("[data-open-view],[data-nav-view]").forEach(el=>el.addEventListener("click",()=>{if(user&&pendingSync)setTimeout(flush,0);}));
  document.addEventListener("visibilitychange",()=>{if(document.visibilityState!=="visible"&&user){window.ourQuranCommitActiveTime?.();flush();}});

  // “Reset all local data” clears this browser/device only. For signed-in users
  // we sign out first so Firestore does not immediately repopulate the local cache.
  // Cloud account data remains safe and will return when the user signs in again.
  els.resetBtn?.addEventListener("click",async e=>{
    if(!user)return; // guest reset continues through app.js's normal reset handler
    e.preventDefault();e.stopImmediatePropagation();
    const ok=confirm("Reset all local OurQuran data on this device? Your Firebase-synced account will stay safe, and you will be signed out.");
    if(!ok)return;
    const uid=user.uid;
    clearTimeout(syncTimer);syncTimer=null;pendingSync=false;
    try{
      localStorage.removeItem(STORAGE_KEY);
      localStorage.removeItem(GUEST_KEY);
      localStorage.removeItem(accountKey(uid));
      localStorage.removeItem(metaKey(uid));
      localStorage.removeItem(baseKey(uid));
      window.ourQuranResetLocalSession?.();
    }catch{}
    try{const {signOut}=firebaseModules.authMod;await signOut(auth);}catch(err){showToast(firebaseError(err));return;}
    user=null;
    state=neutralGuestState(deepDefaultState());
    persistGuestPreferences();
    window.ourQuranProfileEditorCommit?.();
    refreshUI();
    showToast("Local data reset — cloud account kept safe");
  },true);

  async function init(){
    if(!configured()){
      authReady=true;state=neutralGuestState(storedState(GUEST_KEY)||state);persistGuestPreferences();refreshUI();
      syncStatus("guest","Not syncing");
      if(ui.title)ui.title.textContent="Connect an account to save and sync your progress.";
      if(ui.open)ui.open.disabled=false;
      setTimeout(openGuestWelcome,100);
      console.warn("OurQuran Firebase is not configured. Paste the Web App config into site-config.js.");
      return;
    }
    try{
      if(!firebaseInitPromise)firebaseInitPromise=loadFirebase();
      await firebaseInitPromise;
      const {onAuthStateChanged}=firebaseModules.authMod;
      onAuthStateChanged(auth,async current=>{
        authReady=true;
        // Suppress only the duplicate signed-in observer fired by a manual login.
        // A real sign-out must still be processed even if background hydration is running.
        if(manualAuthFlow&&current)return;
        if(current){
          // Returning sessions should appear immediately from local account cache instead
          // of waiting on a Firestore round-trip before the dashboard becomes usable.
          primeSignedInUI(current);
          await hydrate(current);
        }
        else{
          user=null;state=neutralGuestState(storedState(GUEST_KEY)||state);persistGuestPreferences();refreshUI();updateAccountUI();guestPromptHandled=false;setTimeout(openGuestWelcome,100);
        }
      });
    }catch(err){
      console.error(err);authReady=true;user=null;state=neutralGuestState(state);persistGuestPreferences();refreshUI();syncStatus("error","Sync issue");showToast(firebaseError(err));
    }
  }

  init();
})();
