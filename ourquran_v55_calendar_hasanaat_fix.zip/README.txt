OurQuran V40 — Firebase Edition
================================

Current stack
-------------
- Netlify: hosting + Forms feedback
- Firebase Authentication: email/password + Google sign-in + password reset
- Cloud Firestore: profile and reading-progress sync
- Al Quran Cloud + external audio mirrors: Qur'an text/audio sources

Firebase replaces the previous Supabase account layer completely in this build.

What syncs per Firebase user
----------------------------
- Name, username, bio, avatar representation
- Current Surah and Ayah
- Daily hasanaat estimate and ayat count
- Reading time/history/streak inputs
- Theme, reciter, speed, autoplay, text size, contrast
- Adhkar progress and tasbeeh state
- Full OurQuran app state snapshot

The user document also mirrors currentSurah, currentAyah, totalHasanaat,
completedReads, totalSeconds and today's stats as top-level Firestore fields so
they are easy to inspect in the Firebase console.

Guest mode
----------
Guests can see session counters while the tab is open, but reading progress is
not persisted. The left badge says Not saving until an account is signed in.

Accounts
--------
- Email signup is immediate; this build does not request email verification.
- Google sign-in is available once the Google provider is enabled in Firebase.
- Email-password changes require reauthentication with the current password.
- Forgot password uses Firebase's hosted secure password-reset flow.
- Usernames are reserved in the Firestore usernames collection.

Setup
-----
Follow FIREBASE_SETUP.txt before deploying the account system.
Paste firestore.rules into Firestore -> Rules and publish it.

Important
---------
Existing users from the old authentication system are not automatically Firebase
users. A one-time migration would be required if those old test accounts/data
need to be preserved.


V41 — Firebase account shell restored
--------------------------------------
- Uses the actual Firebase Auth + Firestore branch.
- Restored Email/Password + Google account UI.
- Restored fixed left Not syncing / Syncing / Synced indicator.
- Logged-out Profile no longer shows @reader, fake bio text, or local joined text.
- Guest profile editor/security are hidden until a real account is signed in.
- Guest account card is the single clear path to Sign in / Create account.
- Share icon spacing refined.
