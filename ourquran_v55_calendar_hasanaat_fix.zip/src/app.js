const API = "https://api.alquran.cloud/v1";
const STORAGE_KEY = "ourQuranState";
const SITE_CONFIG = window.OURQURAN_CONFIG || {};

// V46: deliberately keep only five reciters with complete, verse-by-verse
// EveryAyah libraries. Every audio file is addressed by the visible Surah + Ayah
// (SSSAAA.mp3), so the sound cannot drift to a different verse.
const RECITERS = [
  { id:"mishary-alafasy", name:"Mishary Rashid Alafasy", folder:"Alafasy_128kbps" },
  { id:"muhammad-ayyoub", name:"Muhammad Ayyoub", folder:"Muhammad_Ayyoub_128kbps" },
  { id:"sudais", name:"Abdul Rahman Al-Sudais", folder:"Abdurrahmaan_As-Sudais_192kbps" },
  { id:"ali-jaber", name:"Ali Jaber", folder:"Ali_Jaber_64kbps" },
  { id:"minshawy", name:"Mohamed Siddiq Al-Minshawi", folder:"Minshawy_Murattal_128kbps" }
];

const RECITER_ID_MIGRATIONS = {
  "maher-almuaiqly":"mishary-alafasy",
  "abu-bakr-shatri":"mishary-alafasy",
  "hani-rifai":"mishary-alafasy",
  "nasser-alqatami":"mishary-alafasy",
  "yasser-ad-dussary":"mishary-alafasy",
  "abdul-basit-murattal":"mishary-alafasy",
  "abdul-basit-mujawwad":"mishary-alafasy",
  "husary":"mishary-alafasy",
  "husary-mujawwad":"mishary-alafasy",
  "minshawy-murattal":"minshawy",
  "minshawy-mujawwad":"minshawy",
  "saood-ash-shuraym":"sudais",
  "ajamy":"mishary-alafasy",
  "hudhaify":"mishary-alafasy",
  "muhammad-jibreel":"mishary-alafasy",
  "ar.alafasy":"mishary-alafasy",
  "ar.minshawi":"minshawy",
  "ar.minshawimujawwad":"minshawy",
  "ar.sudais":"sudais",
  "ar.shuraim":"sudais",
  "ar.muhammadayoub":"muhammad-ayyoub",
  "ar.muhammadayyoub":"muhammad-ayyoub",
  "ar.abdurrahmaansudais":"sudais",
  "ar.abdulbasit":"mishary-alafasy",
  "ar.abdulbasitmujawwad":"mishary-alafasy",
  "ar.ajamy":"mishary-alafasy",
  "ar.hudhaify":"mishary-alafasy",
  "ar.muhammadjibreel":"mishary-alafasy",
  "ar.abdulsamad":"mishary-alafasy",
  "ar.ahmedajamy":"mishary-alafasy",
  "ar.saoodshuraym":"sudais"
};

const ADHKAR = [
  {
    id:"ayat-kursi", modes:["morning","evening"], title:"Ayat al-Kursi", subtitle:"Al-Baqarah 2:255 • 1 time", target:1, timing:"Morning & evening",
    arabic:`أَعُوذُ بِاللهِ مِنَ الشَّيْطَانِ الرَّجِيمِ

اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ ۗ مَنْ ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلَّا بِإِذْنِهِ ۚ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ ۖ وَلَا يُحِيطُونَ بِشَيْءٍ مِنْ عِلْمِهِ إِلَّا بِمَا شَاءَ ۚ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ ۖ وَلَا يَئُودُهُ حِفْظُهُمَا ۚ وَهُوَ الْعَلِيُّ الْعَظِيمُ`,
    translation:"I seek refuge in Allah from the accursed Satan. Allah—there is no deity worthy of worship except Him, the Ever-Living, the Sustainer of all. Neither drowsiness nor sleep overtakes Him. Everything in the heavens and earth belongs to Him. No one can intercede with Him except by His permission. He knows what lies before people and what lies behind them, while they grasp nothing of His knowledge except what He wills. His Kursi encompasses the heavens and the earth, and preserving them does not tire Him. He is the Most High, the Most Great.",
    source:"Hisn al-Muslim 75 • Qur'an 2:255", grade:"Authenticated in Hisn", url:"https://sunnah.com/hisn:75"
  },
  {
    id:"ikhlas", modes:["morning","evening"], title:"Surah Al-Ikhlas", subtitle:"112 • 3 times", target:3, timing:"Morning & evening",
    arabic:`بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ

قُلْ هُوَ اللَّهُ أَحَدٌ ۝ اللَّهُ الصَّمَدُ ۝ لَمْ يَلِدْ وَلَمْ يُولَدْ ۝ وَلَمْ يَكُنْ لَهُ كُفُوًا أَحَدٌ`,
    translation:"In the name of Allah, the Most Compassionate, the Most Merciful. Say: He is Allah, One; Allah, the One upon whom all depend. He neither begets nor was He begotten, and there is none comparable to Him.",
    source:"Hisn al-Muslim 76 • Abu Dawud / Tirmidhi", grade:"Authenticated", url:"https://sunnah.com/hisn:76"
  },
  {
    id:"falaq", modes:["morning","evening"], title:"Surah Al-Falaq", subtitle:"113 • 3 times", target:3, timing:"Morning & evening",
    arabic:`بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ

قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ ۝ مِنْ شَرِّ مَا خَلَقَ ۝ وَمِنْ شَرِّ غَاسِقٍ إِذَا وَقَبَ ۝ وَمِنْ شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ ۝ وَمِنْ شَرِّ حَاسِدٍ إِذَا حَسَدَ`,
    translation:"In the name of Allah, the Most Compassionate, the Most Merciful. Say: I seek refuge in the Lord of daybreak from the evil of what He created; from the evil of darkness when it settles; from the evil of those who blow upon knots; and from the evil of an envier when he envies.",
    source:"Hisn al-Muslim 76 • Abu Dawud / Tirmidhi", grade:"Authenticated", url:"https://sunnah.com/hisn:76"
  },
  {
    id:"nas", modes:["morning","evening"], title:"Surah An-Nas", subtitle:"114 • 3 times", target:3, timing:"Morning & evening",
    arabic:`بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ

قُلْ أَعُوذُ بِرَبِّ النَّاسِ ۝ مَلِكِ النَّاسِ ۝ إِلَٰهِ النَّاسِ ۝ مِنْ شَرِّ الْوَسْوَاسِ الْخَنَّاسِ ۝ الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ ۝ مِنَ الْجِنَّةِ وَالنَّاسِ`,
    translation:"In the name of Allah, the Most Compassionate, the Most Merciful. Say: I seek refuge in the Lord of humankind, the King of humankind, the God of humankind, from the evil of the whisperer who withdraws—the one who whispers into people's hearts—from among jinn and people.",
    source:"Hisn al-Muslim 76 • Abu Dawud / Tirmidhi", grade:"Authenticated", url:"https://sunnah.com/hisn:76"
  },
  {
    id:"kingdom", modes:["morning","evening"], title:"The dominion belongs to Allah", subtitle:"1 time", target:1, timing:"Morning & evening",
    arabicMorning:"أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ، رَبِّ أَسْأَلُكَ خَيْرَ مَا فِي هَذَا الْيَوْمِ وَخَيْرَ مَا بَعْدَهُ، وَأَعُوذُ بِكَ مِنْ شَرِّ مَا فِي هَذَا الْيَوْمِ وَشَرِّ مَا بَعْدَهُ، رَبِّ أَعُوذُ بِكَ مِنَ الْكَسَلِ وَسُوءِ الْكِبَرِ، رَبِّ أَعُوذُ بِكَ مِنْ عَذَابٍ فِي النَّارِ وَعَذَابٍ فِي الْقَبْرِ",
    arabicEvening:"أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ، رَبِّ أَسْأَلُكَ خَيْرَ مَا فِي هَذِهِ اللَّيْلَةِ وَخَيْرَ مَا بَعْدَهَا، وَأَعُوذُ بِكَ مِنْ شَرِّ مَا فِي هَذِهِ اللَّيْلَةِ وَشَرِّ مَا بَعْدَهَا، رَبِّ أَعُوذُ بِكَ مِنَ الْكَسَلِ وَسُوءِ الْكِبَرِ، رَبِّ أَعُوذُ بِكَ مِنْ عَذَابٍ فِي النَّارِ وَعَذَابٍ فِي الْقَبْرِ",
    translationMorning:"We have entered a new morning and all dominion belongs to Allah; all praise belongs to Allah. None has the right to be worshipped but Allah alone, without partner. His is the dominion and His is the praise, and He is able to do all things. My Lord, I ask You for the good of this day and what follows it, and I seek refuge in You from its evil and what follows it. I seek refuge in You from laziness, the hardships of old age, the punishment of the Fire, and the punishment of the grave.",
    translationEvening:"We have entered the evening and all dominion belongs to Allah; all praise belongs to Allah. None has the right to be worshipped but Allah alone, without partner. His is the dominion and His is the praise, and He is able to do all things. My Lord, I ask You for the good of this night and what follows it, and I seek refuge in You from its evil and what follows it. I seek refuge in You from laziness, the hardships of old age, the punishment of the Fire, and the punishment of the grave.",
    source:"Hisn al-Muslim 77 • Sahih Muslim", grade:"Sahih", url:"https://sunnah.com/hisn:77"
  },
  {
    id:"by-you", modes:["morning","evening"], title:"By You we enter morning and evening", subtitle:"1 time", target:1, timing:"Morning & evening",
    arabicMorning:"اللَّهُمَّ بِكَ أَصْبَحْنَا وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا وَبِكَ نَمُوتُ، وَإِلَيْكَ النُّشُورُ",
    arabicEvening:"اللَّهُمَّ بِكَ أَمْسَيْنَا وَبِكَ أَصْبَحْنَا، وَبِكَ نَحْيَا وَبِكَ نَمُوتُ، وَإِلَيْكَ الْمَصِيرُ",
    translationMorning:"O Allah, by You we enter the morning and by You we enter the evening; by You we live and by You we die, and to You is the resurrection.",
    translationEvening:"O Allah, by You we enter the evening and by You we enter the morning; by You we live and by You we die, and to You is the final return.",
    source:"Hisn al-Muslim 78 • Tirmidhi", grade:"Sahih", url:"https://sunnah.com/hisn:78"
  },
  {
    id:"sayyid-istighfar", modes:["morning","evening"], title:"Sayyid al-Istighfar", subtitle:"1 time", target:1, timing:"Morning & evening",
    arabic:"اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ بِذَنْبِي، فَاغْفِرْ لِي فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ",
    translation:"O Allah, You are my Lord; none has the right to be worshipped but You. You created me and I am Your servant. I remain upon Your covenant and promise as much as I am able. I seek refuge in You from the evil of what I have done. I acknowledge Your favour upon me and I acknowledge my sin, so forgive me, for no one forgives sins except You.",
    source:"Hisn al-Muslim 79 • Sahih al-Bukhari", grade:"Sahih", url:"https://sunnah.com/hisn:79"
  },
  {
    id:"witness", modes:["morning","evening"], title:"Bear witness to Allah's oneness", subtitle:"4 times", target:4, timing:"Morning & evening",
    arabicMorning:"اللَّهُمَّ إِنِّي أَصْبَحْتُ أُشْهِدُكَ، وَأُشْهِدُ حَمَلَةَ عَرْشِكَ، وَمَلَائِكَتَكَ، وَجَمِيعَ خَلْقِكَ، أَنَّكَ أَنْتَ اللَّهُ لَا إِلَهَ إِلَّا أَنْتَ وَحْدَكَ لَا شَرِيكَ لَكَ، وَأَنَّ مُحَمَّدًا عَبْدُكَ وَرَسُولُكَ",
    arabicEvening:"اللَّهُمَّ إِنِّي أَمْسَيْتُ أُشْهِدُكَ، وَأُشْهِدُ حَمَلَةَ عَرْشِكَ، وَمَلَائِكَتَكَ، وَجَمِيعَ خَلْقِكَ، أَنَّكَ أَنْتَ اللَّهُ لَا إِلَهَ إِلَّا أَنْتَ وَحْدَكَ لَا شَرِيكَ لَكَ، وَأَنَّ مُحَمَّدًا عَبْدُكَ وَرَسُولُكَ",
    translationMorning:"O Allah, this morning I call You, the bearers of Your Throne, Your angels, and all creation to witness that You are Allah; none has the right to be worshipped but You alone, without partner, and Muhammad is Your servant and Messenger.",
    translationEvening:"O Allah, this evening I call You, the bearers of Your Throne, Your angels, and all creation to witness that You are Allah; none has the right to be worshipped but You alone, without partner, and Muhammad is Your servant and Messenger.",
    source:"Hisn al-Muslim 80 • Abu Dawud", grade:"Hasan chains", url:"https://sunnah.com/hisn:80"
  },
  {
    id:"blessings", modes:["morning","evening"], title:"Acknowledge Allah's blessings", subtitle:"1 time", target:1, timing:"Morning & evening",
    arabicMorning:"اللَّهُمَّ مَا أَصْبَحَ بِي مِنْ نِعْمَةٍ أَوْ بِأَحَدٍ مِنْ خَلْقِكَ، فَمِنْكَ وَحْدَكَ لَا شَرِيكَ لَكَ، فَلَكَ الْحَمْدُ وَلَكَ الشُّكْرُ",
    arabicEvening:"اللَّهُمَّ مَا أَمْسَى بِي مِنْ نِعْمَةٍ أَوْ بِأَحَدٍ مِنْ خَلْقِكَ، فَمِنْكَ وَحْدَكَ لَا شَرِيكَ لَكَ، فَلَكَ الْحَمْدُ وَلَكَ الشُّكْرُ",
    translationMorning:"O Allah, every blessing that has reached me or any of Your creation this morning is from You alone, without partner. All praise and thanks belong to You.",
    translationEvening:"O Allah, every blessing that has reached me or any of Your creation this evening is from You alone, without partner. All praise and thanks belong to You.",
    source:"Hisn al-Muslim 81 • Abu Dawud", grade:"Hasan", url:"https://sunnah.com/hisn:81"
  },
  {
    id:"health", modes:["morning","evening"], title:"Well-being in body, hearing and sight", subtitle:"3 times", target:3, timing:"Morning & evening",
    arabic:"اللَّهُمَّ عَافِنِي فِي بَدَنِي، اللَّهُمَّ عَافِنِي فِي سَمْعِي، اللَّهُمَّ عَافِنِي فِي بَصَرِي، لَا إِلَهَ إِلَّا أَنْتَ. اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْكُفْرِ وَالْفَقْرِ، وَأَعُوذُ بِكَ مِنْ عَذَابِ الْقَبْرِ، لَا إِلَهَ إِلَّا أَنْتَ",
    translation:"O Allah, grant well-being to my body, my hearing, and my sight. None has the right to be worshipped but You. O Allah, I seek refuge in You from disbelief and poverty, and I seek refuge in You from the punishment of the grave. None has the right to be worshipped but You.",
    source:"Hisn al-Muslim 82 • Abu Dawud", grade:"Hasan", url:"https://sunnah.com/hisn:82"
  },
  {
    id:"hasbiyallah", modes:["morning","evening"], title:"Allah is sufficient for me", subtitle:"7 times", target:7, timing:"Morning & evening",
    arabic:"حَسْبِيَ اللَّهُ لَا إِلَهَ إِلَّا هُوَ، عَلَيْهِ تَوَكَّلْتُ، وَهُوَ رَبُّ الْعَرْشِ الْعَظِيمِ",
    translation:"Allah is sufficient for me. None has the right to be worshipped but Him. I place my trust in Him, and He is the Lord of the Mighty Throne.",
    source:"Hisn al-Muslim 83", grade:"Hisn cites a sound chain", url:"https://sunnah.com/hisn:83"
  },
  {
    id:"afiyah", modes:["morning","evening"], title:"Pardon and well-being", subtitle:"1 time", target:1, timing:"Morning & evening",
    arabic:"اللَّهُمَّ إِنِّي أَسْأَلُكَ الْعَفْوَ وَالْعَافِيَةَ فِي الدُّنْيَا وَالْآخِرَةِ، اللَّهُمَّ إِنِّي أَسْأَلُكَ الْعَفْوَ وَالْعَافِيَةَ فِي دِينِي وَدُنْيَايَ وَأَهْلِي وَمَالِي، اللَّهُمَّ اسْتُرْ عَوْرَاتِي وَآمِنْ رَوْعَاتِي، اللَّهُمَّ احْفَظْنِي مِنْ بَيْنِ يَدَيَّ وَمِنْ خَلْفِي وَعَنْ يَمِينِي وَعَنْ شِمَالِي وَمِنْ فَوْقِي، وَأَعُوذُ بِعَظَمَتِكَ أَنْ أُغْتَالَ مِنْ تَحْتِي",
    translation:"O Allah, I ask You for pardon and well-being in this world and the Hereafter; in my religion, my worldly affairs, my family, and my wealth. Conceal my faults and calm my fears. Guard me from in front of me, behind me, on my right, on my left, and above me; and I seek refuge in Your greatness from being struck unexpectedly from beneath me.",
    source:"Hisn al-Muslim 84 • Abu Dawud / Ibn Majah", grade:"Authenticated", url:"https://sunnah.com/hisn:84"
  },
  {
    id:"fatir", modes:["morning","evening"], title:"Refuge from the evil of the self and Shaytan", subtitle:"1 time", target:1, timing:"Morning & evening",
    arabic:"اللَّهُمَّ عَالِمَ الْغَيْبِ وَالشَّهَادَةِ، فَاطِرَ السَّمَاوَاتِ وَالْأَرْضِ، رَبَّ كُلِّ شَيْءٍ وَمَلِيكَهُ، أَشْهَدُ أَنْ لَا إِلَهَ إِلَّا أَنْتَ، أَعُوذُ بِكَ مِنْ شَرِّ نَفْسِي، وَمِنْ شَرِّ الشَّيْطَانِ وَشِرْكِهِ، وَأَنْ أَقْتَرِفَ عَلَى نَفْسِي سُوءًا أَوْ أَجُرَّهُ إِلَى مُسْلِمٍ",
    translation:"O Allah, Knower of the unseen and the seen, Originator of the heavens and the earth, Lord and Sovereign of everything: I testify that none has the right to be worshipped but You. I seek refuge in You from the evil of myself, from the evil of Satan and his call to shirk, and from committing evil against myself or bringing it upon another Muslim.",
    source:"Hisn al-Muslim 85 • Tirmidhi / Abu Dawud", grade:"Authenticated", url:"https://sunnah.com/hisn:85"
  },
  {
    id:"nothing-harms", modes:["morning","evening"], title:"In Allah's name, nothing can harm", subtitle:"3 times", target:3, timing:"Morning & evening",
    arabic:"بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ، وَهُوَ السَّمِيعُ الْعَلِيمُ",
    translation:"In the name of Allah, with whose name nothing on earth or in heaven can cause harm; He is the All-Hearing, the All-Knowing.",
    source:"Hisn al-Muslim 86 • Abu Dawud / Tirmidhi", grade:"Hasan", url:"https://sunnah.com/hisn:86"
  },
  {
    id:"pleased", modes:["morning","evening"], title:"Pleased with Allah, Islam and Muhammad ﷺ", subtitle:"3 times", target:3, timing:"Morning & evening",
    arabic:"رَضِيتُ بِاللَّهِ رَبًّا، وَبِالْإِسْلَامِ دِينًا، وَبِمُحَمَّدٍ ﷺ نَبِيًّا",
    translation:"I am pleased with Allah as my Lord, with Islam as my religion, and with Muhammad ﷺ as my Prophet.",
    source:"Hisn al-Muslim 87", grade:"Hasan", url:"https://sunnah.com/hisn:87"
  },
  {
    id:"hayy-qayyum", modes:["morning","evening"], title:"O Ever-Living, O Sustainer", subtitle:"1 time", target:1, timing:"Morning & evening",
    arabic:"يَا حَيُّ يَا قَيُّومُ، بِرَحْمَتِكَ أَسْتَغِيثُ، أَصْلِحْ لِي شَأْنِي كُلَّهُ، وَلَا تَكِلْنِي إِلَى نَفْسِي طَرْفَةَ عَيْنٍ",
    translation:"O Ever-Living, O Sustainer, by Your mercy I seek help. Set right all of my affairs and do not leave me to myself even for the blink of an eye.",
    source:"Hisn al-Muslim 88", grade:"Sahih chain", url:"https://sunnah.com/hisn:88"
  },
  {
    id:"good-day-night", modes:["morning","evening"], title:"Ask for the good of the day / night", subtitle:"1 time", target:1, timing:"Morning & evening",
    arabicMorning:"أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ رَبِّ الْعَالَمِينَ، اللَّهُمَّ إِنِّي أَسْأَلُكَ خَيْرَ هَذَا الْيَوْمِ: فَتْحَهُ، وَنَصْرَهُ، وَنُورَهُ، وَبَرَكَتَهُ، وَهُدَاهُ، وَأَعُوذُ بِكَ مِنْ شَرِّ مَا فِيهِ وَشَرِّ مَا بَعْدَهُ",
    arabicEvening:"أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ رَبِّ الْعَالَمِينَ، اللَّهُمَّ إِنِّي أَسْأَلُكَ خَيْرَ هَذِهِ اللَّيْلَةِ: فَتْحَهَا، وَنَصْرَهَا، وَنُورَهَا، وَبَرَكَتَهَا، وَهُدَاهَا، وَأَعُوذُ بِكَ مِنْ شَرِّ مَا فِيهَا وَشَرِّ مَا بَعْدَهَا",
    translationMorning:"We have entered the morning and all dominion belongs to Allah, Lord of all worlds. O Allah, I ask You for the good of this day—its opening, victory, light, blessing, and guidance—and I seek refuge in You from the evil within it and the evil that follows it.",
    translationEvening:"We have entered the evening and all dominion belongs to Allah, Lord of all worlds. O Allah, I ask You for the good of this night—its opening, victory, light, blessing, and guidance—and I seek refuge in You from the evil within it and the evil that follows it.",
    source:"Hisn al-Muslim 89 • Abu Dawud", grade:"Hasan", url:"https://sunnah.com/hisn:89"
  },
  {
    id:"fitrah", modes:["morning","evening"], title:"Upon the natural religion of Islam", subtitle:"1 time", target:1, timing:"Morning & evening",
    arabicMorning:"أَصْبَحْنَا عَلَى فِطْرَةِ الْإِسْلَامِ، وَعَلَى كَلِمَةِ الْإِخْلَاصِ، وَعَلَى دِينِ نَبِيِّنَا مُحَمَّدٍ ﷺ، وَعَلَى مِلَّةِ أَبِينَا إِبْرَاهِيمَ حَنِيفًا مُسْلِمًا وَمَا كَانَ مِنَ الْمُشْرِكِينَ",
    arabicEvening:"أَمْسَيْنَا عَلَى فِطْرَةِ الْإِسْلَامِ، وَعَلَى كَلِمَةِ الْإِخْلَاصِ، وَعَلَى دِينِ نَبِيِّنَا مُحَمَّدٍ ﷺ، وَعَلَى مِلَّةِ أَبِينَا إِبْرَاهِيمَ حَنِيفًا مُسْلِمًا وَمَا كَانَ مِنَ الْمُشْرِكِينَ",
    translationMorning:"We have entered the morning upon the natural way of Islam, the word of sincere devotion, the religion of our Prophet Muhammad ﷺ, and the way of our father Ibrahim, upright and Muslim, who was not among those who associated partners with Allah.",
    translationEvening:"We have entered the evening upon the natural way of Islam, the word of sincere devotion, the religion of our Prophet Muhammad ﷺ, and the way of our father Ibrahim, upright and Muslim, who was not among those who associated partners with Allah.",
    source:"Hisn al-Muslim 90", grade:"Reported in Ahmad / Nasa'i / Tirmidhi", url:"https://sunnah.com/hisn:90"
  },
  {
    id:"subhan-bihamdih", modes:["morning","evening"], title:"SubhanAllahi wa bihamdih", subtitle:"100 times", target:100, timing:"Morning & evening",
    arabic:"سُبْحَانَ اللَّهِ وَبِحَمْدِهِ",
    translation:"Glory be to Allah, and praise belongs to Him.",
    source:"Hisn al-Muslim 91", grade:"Sahih", url:"https://sunnah.com/hisn:91"
  },
  {
    id:"tahlil-ten", modes:["morning","evening"], title:"La ilaha illa Allah — morning/evening form", subtitle:"10 times", target:10, timing:"Morning & evening",
    arabic:"لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ، وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ",
    translation:"None has the right to be worshipped but Allah alone, without partner. His is the dominion and His is the praise, and He is able to do all things.",
    source:"Hisn al-Muslim 92", grade:"Sahih / Hasan reports cited", url:"https://sunnah.com/hisn:92"
  },
  {
    id:"tahlil-hundred", modes:["morning","evening"], sharedDaily:true, title:"La ilaha illa Allah — 100 in the day", subtitle:"100 times • shared daily count", target:100, timing:"Daily; commonly started in the morning",
    arabic:"لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ، وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ",
    translation:"None has the right to be worshipped but Allah alone, without partner. His is the dominion and His is the praise, and He is able to do all things.",
    source:"Hisn al-Muslim 93 • Bukhari / Muslim", grade:"Sahih", url:"https://sunnah.com/hisn:93"
  },
  {
    id:"creation-count", modes:["morning"], title:"By the number of His creation", subtitle:"3 times • morning", target:3, timing:"Morning only",
    arabic:"سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، عَدَدَ خَلْقِهِ، وَرِضَا نَفْسِهِ، وَزِنَةَ عَرْشِهِ، وَمِدَادَ كَلِمَاتِهِ",
    translation:"Glory be to Allah and praise be to Him—by the number of His creation, by His pleasure, by the weight of His Throne, and by the extent of His words.",
    source:"Hisn al-Muslim 94 • Sahih Muslim", grade:"Sahih", url:"https://sunnah.com/hisn:94"
  },
  {
    id:"beneficial-knowledge", modes:["morning"], title:"Beneficial knowledge, good provision, accepted deeds", subtitle:"1 time • morning", target:1, timing:"Morning only",
    arabic:"اللَّهُمَّ إِنِّي أَسْأَلُكَ عِلْمًا نَافِعًا، وَرِزْقًا طَيِّبًا، وَعَمَلًا مُتَقَبَّلًا",
    translation:"O Allah, I ask You for beneficial knowledge, good and wholesome provision, and deeds that are accepted.",
    source:"Hisn al-Muslim 95 • Ibn Majah", grade:"Hasan", url:"https://sunnah.com/hisn:95"
  },
  {
    id:"istighfar-hundred", modes:["morning","evening"], sharedDaily:true, title:"Seek Allah's forgiveness and repent", subtitle:"100 times during the day • shared count", target:100, timing:"Daily — any time",
    arabic:"أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ",
    translation:"I seek Allah's forgiveness and repent to Him.",
    source:"Hisn al-Muslim 96 • Bukhari / Muslim", grade:"Sahih", url:"https://sunnah.com/hisn:96"
  },
  {
    id:"perfect-words", modes:["evening"], title:"Refuge in Allah's perfect words", subtitle:"3 times • evening", target:3, timing:"Evening only",
    arabic:"أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ",
    translation:"I seek refuge in the perfect words of Allah from the evil of what He created.",
    source:"Hisn al-Muslim 97", grade:"Sahih / Hasan reports cited", url:"https://sunnah.com/hisn:97"
  },
  {
    id:"salawat-ten", modes:["morning","evening"], title:"Send peace and blessings upon the Prophet ﷺ", subtitle:"10 times", target:10, timing:"Morning & evening",
    arabic:"اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ",
    translation:"O Allah, send Your peace and blessings upon our Prophet Muhammad.",
    source:"Hisn al-Muslim 98", grade:"Jayyid chain cited in Hisn", url:"https://sunnah.com/hisn:98"
  },
  {
    id:"baqarah-end", modes:["evening"], title:"The last two verses of Al-Baqarah", subtitle:"2:285–286 • 1 time", target:1, timing:"Night / before sleep",
    arabic:"آمَنَ الرَّسُولُ بِمَا أُنْزِلَ إِلَيْهِ مِنْ رَبِّهِ وَالْمُؤْمِنُونَ ۚ كُلٌّ آمَنَ بِاللَّهِ وَمَلَائِكَتِهِ وَكُتُبِهِ وَرُسُلِهِ لَا نُفَرِّقُ بَيْنَ أَحَدٍ مِنْ رُسُلِهِ ۚ وَقَالُوا سَمِعْنَا وَأَطَعْنَا ۖ غُفْرَانَكَ رَبَّنَا وَإِلَيْكَ الْمَصِيرُ ۝ لَا يُكَلِّفُ اللَّهُ نَفْسًا إِلَّا وُسْعَهَا ۚ لَهَا مَا كَسَبَتْ وَعَلَيْهَا مَا اكْتَسَبَتْ ۗ رَبَّنَا لَا تُؤَاخِذْنَا إِنْ نَسِينَا أَوْ أَخْطَأْنَا ۚ رَبَّنَا وَلَا تَحْمِلْ عَلَيْنَا إِصْرًا كَمَا حَمَلْتَهُ عَلَى الَّذِينَ مِنْ قَبْلِنَا ۚ رَبَّنَا وَلَا تُحَمِّلْنَا مَا لَا طَاقَةَ لَنَا بِهِ ۖ وَاعْفُ عَنَّا وَاغْفِرْ لَنَا وَارْحَمْنَا ۚ أَنْتَ مَوْلَانَا فَانْصُرْنَا عَلَى الْقَوْمِ الْكَافِرِينَ",
    translation:"The Messenger believes in what was sent down to him from his Lord, and so do the believers. Each believes in Allah, His angels, His books, and His messengers, making no distinction between His messengers. They say: We hear and obey. We seek Your forgiveness, our Lord, and to You is the return. Allah does not burden a soul beyond its capacity. Each soul receives the good it earns and bears the evil it commits. Our Lord, do not take us to task if we forget or make a mistake. Do not place on us a burden like the one placed on those before us. Do not burden us with what we cannot bear. Pardon us, forgive us, and have mercy on us. You are our Protector, so grant us help against those who reject faith.",
    source:"Hisn al-Muslim 101 • Bukhari / Muslim", grade:"Sahih", url:"https://sunnah.com/hisn:101"
  }
];

const ALLAH_NAMES = [
["الرَّحْمَنُ","Ar-Rahman","The Universally Merciful"],["الرَّحِيمُ","Ar-Rahim","The Especially Merciful"],["الْمَلِكُ","Al-Malik","The King and Sovereign"],["الْقُدُّوسُ","Al-Quddus","The Absolutely Pure and Holy"],["السَّلَامُ","As-Salam","The Source of Peace and Perfection"],["الْمُؤْمِنُ","Al-Mu'min","The Granter of Security"],["الْمُهَيْمِنُ","Al-Muhaymin","The Guardian and Overseer"],["الْعَزِيزُ","Al-Aziz","The Almighty"],["الْجَبَّارُ","Al-Jabbar","The Compeller and Restorer"],["الْمُتَكَبِّرُ","Al-Mutakabbir","The Supremely Great"],
["الْخَالِقُ","Al-Khaliq","The Creator"],["الْبَارِئُ","Al-Bari'","The Originator"],["الْمُصَوِّرُ","Al-Musawwir","The Fashioner"],["الْغَفَّارُ","Al-Ghaffar","The Constant Forgiver"],["الْقَهَّارُ","Al-Qahhar","The All-Subduing"],["الْوَهَّابُ","Al-Wahhab","The Supreme Bestower"],["الرَّزَّاقُ","Ar-Razzaq","The Provider"],["الْفَتَّاحُ","Al-Fattah","The Opener and Judge"],["الْعَلِيمُ","Al-'Alim","The All-Knowing"],["الْقَابِضُ","Al-Qabid","The Withholder"],
["الْبَاسِطُ","Al-Basit","The Expander"],["الْخَافِضُ","Al-Khafid","The One Who Lowers"],["الرَّافِعُ","Ar-Rafi'","The One Who Raises"],["الْمُعِزُّ","Al-Mu'izz","The Giver of Honor"],["الْمُذِلُّ","Al-Mudhill","The One Who Humbles"],["السَّمِيعُ","As-Sami'","The All-Hearing"],["الْبَصِيرُ","Al-Basir","The All-Seeing"],["الْحَكَمُ","Al-Hakam","The Perfect Judge"],["الْعَدْلُ","Al-'Adl","The Utterly Just"],["اللَّطِيفُ","Al-Latif","The Subtle and Gentle"],
["الْخَبِيرُ","Al-Khabir","The All-Aware"],["الْحَلِيمُ","Al-Halim","The Most Forbearing"],["الْعَظِيمُ","Al-'Azim","The Magnificent"],["الْغَفُورُ","Al-Ghafur","The Great Forgiver"],["الشَّكُورُ","Ash-Shakur","The Most Appreciative"],["الْعَلِيُّ","Al-'Aliyy","The Most High"],["الْكَبِيرُ","Al-Kabir","The Most Great"],["الْحَفِيظُ","Al-Hafiz","The Preserver"],["الْمُقِيتُ","Al-Muqit","The Sustainer"],["الْحَسِيبُ","Al-Hasib","The Reckoner and Sufficient One"],
["الْجَلِيلُ","Al-Jalil","The Majestic"],["الْكَرِيمُ","Al-Karim","The Most Generous"],["الرَّقِيبُ","Ar-Raqib","The Watchful"],["الْمُجِيبُ","Al-Mujib","The Responsive"],["الْوَاسِعُ","Al-Wasi'","The All-Encompassing"],["الْحَكِيمُ","Al-Hakim","The All-Wise"],["الْوَدُودُ","Al-Wadud","The Most Loving"],["الْمَجِيدُ","Al-Majid","The Glorious"],["الْبَاعِثُ","Al-Ba'ith","The Resurrector"],["الشَّهِيدُ","Ash-Shahid","The Witness"],
["الْحَقُّ","Al-Haqq","The Absolute Truth"],["الْوَكِيلُ","Al-Wakil","The Trustee and Disposer of Affairs"],["الْقَوِيُّ","Al-Qawiyy","The All-Strong"],["الْمَتِينُ","Al-Matin","The Firm and Steadfast"],["الْوَلِيُّ","Al-Waliyy","The Protecting Ally"],["الْحَمِيدُ","Al-Hamid","The Praiseworthy"],["الْمُحْصِي","Al-Muhsi","The One Who Encompasses All in Count"],["الْمُبْدِئُ","Al-Mubdi'","The Initiator"],["الْمُعِيدُ","Al-Mu'id","The Restorer"],["الْمُحْيِي","Al-Muhyi","The Giver of Life"],
["الْمُمِيتُ","Al-Mumit","The Bringer of Death"],["الْحَيُّ","Al-Hayy","The Ever-Living"],["الْقَيُّومُ","Al-Qayyum","The Self-Subsisting Sustainer"],["الْوَاجِدُ","Al-Wajid","The One Who Lacks Nothing"],["الْمَاجِدُ","Al-Maajid","The Illustrious"],["الْوَاحِدُ","Al-Wahid","The One"],["الْأَحَدُ","Al-Ahad","The Unique One"],["الصَّمَدُ","As-Samad","The Eternal Refuge"],["الْقَادِرُ","Al-Qadir","The Fully Able"],["الْمُقْتَدِرُ","Al-Muqtadir","The Perfectly Powerful"],
["الْمُقَدِّمُ","Al-Muqaddim","The One Who Brings Forward"],["الْمُؤَخِّرُ","Al-Mu'akhkhir","The One Who Delays"],["الْأَوَّلُ","Al-Awwal","The First"],["الْآخِرُ","Al-Akhir","The Last"],["الظَّاهِرُ","Az-Zahir","The Manifest"],["الْبَاطِنُ","Al-Batin","The Hidden and Near"],["الْوَالِي","Al-Waali","The Governor"],["الْمُتَعَالِي","Al-Muta'ali","The Supremely Exalted"],["الْبَرُّ","Al-Barr","The Source of Goodness"],["التَّوَّابُ","At-Tawwab","The Accepter of Repentance"],
["الْمُنْتَقِمُ","Al-Muntaqim","The Just Avenger"],["الْعَفُوُّ","Al-'Afuww","The Pardoner"],["الرَّؤُوفُ","Ar-Ra'uf","The Most Kind"],["مَالِكُ الْمُلْكِ","Malik-ul-Mulk","Owner of All Sovereignty"],["ذُو الْجَلَالِ وَالْإِكْرَامِ","Dhul-Jalali wal-Ikram","Lord of Majesty and Honor"],["الْمُقْسِطُ","Al-Muqsit","The Perfectly Just"],["الْجَامِعُ","Al-Jami'","The Gatherer"],["الْغَنِيُّ","Al-Ghaniyy","The Self-Sufficient"],["الْمُغْنِي","Al-Mughni","The Enricher"],["الْمَانِعُ","Al-Mani'","The Preventer"],
["الضَّارُّ","Ad-Darr","The One Who Permits Harm"],["النَّافِعُ","An-Nafi'","The Giver of Benefit"],["النُّورُ","An-Nur","The Light"],["الْهَادِي","Al-Hadi","The Guide"],["الْبَدِيعُ","Al-Badi'","The Incomparable Originator"],["الْبَاقِي","Al-Baqi","The Everlasting"],["الْوَارِثُ","Al-Warith","The Inheritor"],["الرَّشِيدُ","Ar-Rashid","The Guide to the Right Way"],["الصَّبُورُ","As-Sabur","The Perfectly Patient"]
];



const els = Object.fromEntries([
  "surahSelect","ayahSelect","surahName","surahEnglish","ayahNumber","arabicText","translationText",
  "totalHasanaat","completedCount","gainPreview","reciterQuickBtn","speedQuickBtn","autoplayQuickBtn","textSizeQuickBtn",
  "prevBtn","nextBtn","audioBtn","audioIcon","audioLabel","audioPlayer","positionMeta","juzMeta","bismillahText",
  "sessionTime","currentReciterLabel","currentSpeedLabel","currentAutoplayLabel","currentTextSizeLabel",
  "settingsDrawer","drawerOverlay","closeSettingsBtn","autoplayToggle",
  "speedSelect","reciterSelect","resetBtn","toast","ayahStage","dashAllTime","dashToday",
  "dashWeek","dashMonth","dashTodayAyat","dashWeekAyat","dashMonthAyat","todayRange","weekRange","monthRange",
  "weeklyBars","dashboardSessionTime","dashboardWeekTime","dashboardMonthTime","dashboardAllTimeSpent","dashboardCurrentSessionTime",
  "dashMorningDone","dashMorningTotal","dashEveningDone","dashEveningTotal",
  "adhkarList","adhkarDoneCount","adhkarTotalCount","adhkarProgressFill","adhkarProgressLabel","resetAdhkarBtn",
  "tasbeehPreset","tasbeehTarget","tasbeehPhrase","tasbeehButton","tasbeehCount","tasbeehTargetLabel","tasbeehRemaining","tasbeehMeterFill","tasbeehReset",
  "namesGrid","namesSearch","visibleNamesCount",
  "shareHomeBtn","shareProfileBtn","continueReadingBtn","homeContinueSurah","homeContinueAyah","homeContinueHeadline",
  "continueTodayHasanaat","continueWeekHasanaat","continueMonthHasanaat",
  "weekHabitRow","homeCurrentStreak","personalBest","personalBestDate","prToday","prProgressFill","prMessage",
  "streakCurrent","streakLongest","activeDaysCount","bottomSettingsBtn",
  "profileAvatar","profileNameDisplay","profileHandleDisplay","profileBioDisplay","profileJoined","profileFullNameInput","profileUsernameInput","profileBioInput","profileBioCount","profileAvatarButton","profileAvatarInput","profileAvatarEditPreview","removeProfileAvatarBtn","saveProfileNameBtn",
  
  "homeGreetingName","shareSiteHomeBtn","shareSiteProfileBtn","inviteFriendsBtn","copyFriendCodeBtn","friendCodeDisplay",
  "friendSearchInput","addFriendBtn","friendsList","incomingInviteBox","textSizeSelect","contrastToggle",
  "shareSheet","shareSheetOverlay","closeShareSheetBtn","shareSheetTitle","shareSheetDescription","sharePreviewNotice",
  "nativeShareBtn","whatsappShareLink","emailShareLink","copyShareTextBtn","copyShareLinkBtn","shareLinkLabel",
  "supportBtn","feedbackBtn","supportModal","closeSupportBtn","supportPaymentLink","supportSetupNotice",
  "feedbackModal","closeFeedbackBtn","feedbackForm","feedbackName","feedbackEmailInput","feedbackCategory","feedbackMessage",
  "feedbackCharCount","feedbackStatus","submitFeedbackBtn",
  "feedbackViewField","feedbackThemeField","feedbackVersionField","feedbackSubmittedAtField",
  "quickThemeButton","quickThemeLabel","quickThemePopover"
].map(id => [id, document.getElementById(id)]));

const defaultState = {
  surah: 1,
  ayah: 1,
  totalHasanaat: 0,
  completedReads: 0,
  totalSeconds: 0,
  history: {},
  adhkarProgress: {},
  tasbeeh: { phrase: "سُبْحَانَ اللهِ", count: 0, target: 33 },
  profile: { fullName: "", displayName: "Reader", username: "reader", bio: "", avatarDataUrl: "", joinedAt: "", friendCode: "" },
  friends: [],
  incomingInvite: null,
  migrations: {},
  timeTracking: { sessionSeconds: 0, sessionStartedAt: 0, lastActiveAt: 0 },
  settings: { autoplay: true, speed: 1, reciter: "mishary-alafasy", textSize: "standard", highContrast: true, theme: "kaaba" }
};

let state = loadState();
let surahs = [];
let currentSurahArabic = null;
let currentSurahEnglish = null;
let currentAyah = null;
let currentTranslation = null;
let currentReward = 0;
let sessionStart = Date.now();
let sessionHasanaat = 0;
let sessionAyat = 0;
let isTransitioning = false;
let currentViewId = "dashboardView";

function deepDefaultState() { return JSON.parse(JSON.stringify(defaultState)); }
function loadState() {
  try {
    const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}");
    const next = {
      ...deepDefaultState(),
      ...parsed,
      history: parsed.history || {},
      adhkarProgress: parsed.adhkarProgress || {},
      tasbeeh: { ...defaultState.tasbeeh, ...(parsed.tasbeeh || {}) },
      profile: { ...defaultState.profile, ...(parsed.profile || {}) },
      friends: Array.isArray(parsed.friends) ? parsed.friends : [],
      incomingInvite: parsed.incomingInvite || null,
      migrations: { ...(parsed.migrations || {}) },
      timeTracking: { ...defaultState.timeTracking, ...(parsed.timeTracking || {}) },
      settings: { ...defaultState.settings, ...(parsed.settings || {}) }
    };
    // V8 used “comfortable” for Standard. Normalize it so the new scale is predictable.
    if (next.settings.textSize === "comfortable") next.settings.textSize = "standard";
    if (!["standard","large","xlarge"].includes(next.settings.textSize)) next.settings.textSize = "standard";
    if (!["kaaba","sunset","dark","light"].includes(next.settings.theme)) next.settings.theme = "kaaba";
    if (RECITER_ID_MIGRATIONS[next.settings.reciter]) next.settings.reciter = RECITER_ID_MIGRATIONS[next.settings.reciter];
    if (!RECITERS.some(r => r.id === next.settings.reciter)) next.settings.reciter = "mishary-alafasy";
    for (const rec of Object.values(next.history)) {
      rec.hasanaat = Number(rec.hasanaat || 0);
      rec.ayat = Number(rec.ayat || 0);
      rec.seconds = Number(rec.seconds || 0);
    }
    const datedHasanaat = Object.values(next.history).reduce((sum,rec)=>sum+Number(rec.hasanaat||0),0);
    next.totalHasanaat = Math.max(Number(next.totalHasanaat||0), datedHasanaat);
    const datedSeconds = Object.values(next.history).reduce((sum,rec)=>sum+Number(rec.seconds||0),0);
    next.totalSeconds = Math.max(Number(next.totalSeconds||0), datedSeconds);
    return next;
  } catch { return deepDefaultState(); }
}
function saveState() { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }

function localDateKey(date = new Date()) {
  const y = date.getFullYear();
  const m = String(date.getMonth()+1).padStart(2,"0");
  const d = String(date.getDate()).padStart(2,"0");
  return `${y}-${m}-${d}`;
}
function dateFromKey(key) {
  const [y,m,d] = key.split("-").map(Number);
  return new Date(y,m-1,d,12,0,0,0);
}
function ensureHistoryDay(key = localDateKey()) {
  if (!state.history[key]) state.history[key] = { hasanaat:0, ayat:0, seconds:0 };
  state.history[key].hasanaat = Number(state.history[key].hasanaat || 0);
  state.history[key].ayat = Number(state.history[key].ayat || 0);
  state.history[key].seconds = Number(state.history[key].seconds || 0);
  return state.history[key];
}
function startOfDay(date) { const d=new Date(date); d.setHours(0,0,0,0); return d; }
function endOfDay(date) { const d=new Date(date); d.setHours(23,59,59,999); return d; }
function startOfWeek(date = new Date()) {
  // OurQuran uses a fixed Sunday → Saturday calendar week so the dashboard never shifts by browser locale.
  const d = startOfDay(date);
  d.setDate(d.getDate() - d.getDay());
  return d;
}
function endOfWeek(date = new Date()) { const d=startOfWeek(date); d.setDate(d.getDate()+6); return endOfDay(d); }
function startOfMonth(date = new Date()) { return new Date(date.getFullYear(), date.getMonth(), 1); }
function endOfMonth(date = new Date()) { return endOfDay(new Date(date.getFullYear(), date.getMonth()+1, 0)); }
function inRange(key, start, end) { const d=dateFromKey(key); return d>=start && d<=end; }
function sumHistory(start, end) {
  return Object.entries(state.history).reduce((acc,[key,val]) => {
    if (inRange(key,start,end)) { acc.hasanaat += Number(val.hasanaat||0); acc.ayat += Number(val.ayat||0); }
    return acc;
  }, {hasanaat:0,ayat:0});
}
function formatDate(date, opts={month:"short",day:"numeric"}) { return new Intl.DateTimeFormat(undefined,opts).format(date); }
function formatNumber(num) { return Number(num||0).toLocaleString(); }
function reconcileLegacyCalendarData(){
  if(state.migrations?.v9CalendarReconciled) return;
  state.migrations = state.migrations || {};
  const todayKey=localDateKey();
  const joined=state.profile?.joinedAt ? new Date(state.profile.joinedAt) : null;
  const joinedToday=joined && !Number.isNaN(joined.getTime()) && localDateKey(joined)===todayKey;
  const datedHasanaat=Object.values(state.history).reduce((sum,rec)=>sum+Number(rec.hasanaat||0),0);
  const datedAyat=Object.values(state.history).reduce((sum,rec)=>sum+Number(rec.ayat||0),0);
  // During the prototype versions, lifetime totals existed before daily history did.
  // If this local profile was created today, the safe assumption is that the undated prototype balance belongs to today.
  if(joinedToday){
    const day=ensureHistoryDay(todayKey);
    const missingHasanaat=Math.max(0,Number(state.totalHasanaat||0)-datedHasanaat);
    const missingAyat=Math.max(0,Number(state.completedReads||0)-datedAyat);
    day.hasanaat+=missingHasanaat;
    day.ayat+=missingAyat;
  }
  const newDatedHasanaat=Object.values(state.history).reduce((sum,rec)=>sum+Number(rec.hasanaat||0),0);
  const newDatedAyat=Object.values(state.history).reduce((sum,rec)=>sum+Number(rec.ayat||0),0);
  state.totalHasanaat=Math.max(Number(state.totalHasanaat||0),newDatedHasanaat);
  state.completedReads=Math.max(Number(state.completedReads||0),newDatedAyat);
  state.migrations.v9CalendarReconciled=true;
  saveState();
}
function formatDuration(totalSeconds) {
  const sec = Math.max(0, Math.floor(Number(totalSeconds || 0)));
  const h = String(Math.floor(sec / 3600)).padStart(2,"0");
  const m = String(Math.floor((sec % 3600) / 60)).padStart(2,"0");
  const s = String(sec % 60).padStart(2,"0");
  return `${h}:${m}:${s}`;
}
function secondsInRange(start,end){
  return Object.entries(state.history).reduce((sum,[key,rec])=>inRange(key,start,end)?sum+Number(rec.seconds||0):sum,0);
}

function syncDerivedTotalsFromHistory(){
  const totals = Object.values(state.history).reduce((acc,rec)=>{
    acc.hasanaat += Number(rec.hasanaat || 0);
    acc.ayat += Number(rec.ayat || 0);
    acc.seconds += Number(rec.seconds || 0);
    return acc;
  }, {hasanaat:0, ayat:0, seconds:0});

  // After the legacy reconciliation has run, history becomes the single source of truth.
  state.totalHasanaat = totals.hasanaat;
  state.completedReads = totals.ayat;
  state.totalSeconds = totals.seconds;
  return totals;
}

function applyTheme(){
  const theme = ["kaaba","sunset","dark","light"].includes(state.settings.theme) ? state.settings.theme : "kaaba";
  document.documentElement.dataset.theme = theme;
  document.body.dataset.theme = theme;
  document.documentElement.style.colorScheme = theme === "light" ? "light" : "dark";
  document.querySelectorAll("[data-theme-option]").forEach(btn=>{
    const active = btn.dataset.themeOption === theme;
    btn.classList.toggle("active", active);
    btn.setAttribute("aria-pressed", String(active));
  });
  const quickThemeNames={kaaba:"Kaaba",sunset:"Sunset Amber",dark:"Dark",light:"Light"};
  if(els.quickThemeLabel) els.quickThemeLabel.textContent=quickThemeNames[theme]||"Kaaba";
  document.querySelectorAll("[data-quick-theme]").forEach(btn=>{
    const active=btn.dataset.quickTheme===theme;
    btn.classList.toggle("active",active);
    btn.setAttribute("aria-checked",String(active));
  });
}

function renderTimeDisplays(){
  // V48: historical timers were removed from the dashboard. The only visible clock
  // is the local Reader session timer, which is intentionally not account-synced.
  window.ourQuranRenderLocalSession?.();
}

function countArabicLetters(text) {
  let count = 0;
  for (const ch of text.normalize("NFC")) {
    if (/\p{Letter}/u.test(ch) && /\p{Script=Arabic}/u.test(ch)) count++;
  }
  return count;
}
function showToast(message) {
  els.toast.textContent = message;
  els.toast.classList.add("show");
  clearTimeout(showToast._t);
  showToast._t = setTimeout(()=>els.toast.classList.remove("show"),1600);
}
async function fetchJson(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Request failed: ${res.status}`);
  const json = await res.json();
  if (json.code !== 200 || !json.data) throw new Error("Unexpected Qur'an API response.");
  return json.data;
}

function currentReciter(){ return RECITERS.find(r=>r.id===state.settings.reciter)||RECITERS[0]; }

function pad3(value){
  return String(Number(value)).padStart(3,"0");
}

let currentSurahAudio = null;
let currentSurahAudioEdition = null;
let currentSurahAudioNumber = null;

// Kept as a lightweight compatibility hook for the existing reader flow.
// EveryAyah URLs are deterministic and do not need per-surah metadata fetches.
async function loadCurrentSurahAudio(){
  currentSurahAudio = null;
  currentSurahAudioEdition = currentReciter().id;
  currentSurahAudioNumber = Number(state.surah);
  return true;
}

function audioCandidatesForAyah(){
  const reciter=currentReciter();
  const surah=Number(state.surah);
  const ayah=Number(state.ayah);
  if(!reciter?.folder || !Number.isInteger(surah) || !Number.isInteger(ayah) || surah<1 || surah>114 || ayah<1) return [];
  const verseKey=`${surah}:${ayah}`;
  const file=`${pad3(surah)}${pad3(ayah)}.mp3`;
  return [{
    provider:"EveryAyah",
    verseKey,
    url:`https://everyayah.com/data/${reciter.folder}/${file}`
  }];
}

function audioUrlForAyah(){
  return audioCandidatesForAyah()[0]?.url || "";
}

function requestedPlaybackRate(){
  return Math.min(2, Math.max(.5, Number(state.settings.speed) || 1));
}

function applyPlaybackPreferences(){
  const rate = requestedPlaybackRate();
  const audio = els.audioPlayer;

  // Set both values. defaultPlaybackRate covers future loads; playbackRate
  // controls the audio that is loaded right now.
  if(Math.abs(Number(audio.defaultPlaybackRate || 1) - rate) > 0.0001){
    audio.defaultPlaybackRate = rate;
  }
  if(Math.abs(Number(audio.playbackRate || 1) - rate) > 0.0001){
    audio.playbackRate = rate;
  }

  audio.dataset.requestedPlaybackRate = String(rate);

  // Preserve the reciter's natural pitch while changing tempo.
  if("preservesPitch" in audio) audio.preservesPitch = true;
  if("webkitPreservesPitch" in audio) audio.webkitPreservesPitch = true;
  if("mozPreservesPitch" in audio) audio.mozPreservesPitch = true;
}

function populateReciters(){
  els.reciterSelect.innerHTML=RECITERS.map(r=>`<option value="${r.id}">${r.name}</option>`).join("");
  els.reciterSelect.value=state.settings.reciter;
}
function populateSurahSelect(){ els.surahSelect.innerHTML=surahs.map(s=>`<option value="${s.number}">${s.number}. ${s.englishName}</option>`).join(""); els.surahSelect.value=state.surah; }
function populateAyahSelect(total){ els.ayahSelect.innerHTML=Array.from({length:total},(_,i)=>`<option value="${i+1}">${i+1}</option>`).join(""); els.ayahSelect.value=state.ayah; }

function renderSettingSummary(){
  els.currentReciterLabel.textContent=currentReciter().name;
  els.currentSpeedLabel.textContent=`${Number(state.settings.speed).toFixed(2).replace(/\.00$/,'.0')}×`;
  els.currentAutoplayLabel.textContent=state.settings.autoplay?"On":"Off";
  const textLabels={standard:"Standard",large:"Large",xlarge:"Extra large"};
  if(els.currentTextSizeLabel) els.currentTextSizeLabel.textContent=textLabels[state.settings.textSize]||"Standard";
  els.autoplayQuickBtn?.classList.toggle("is-off",!state.settings.autoplay);
  els.autoplayQuickBtn?.setAttribute("aria-pressed",String(!!state.settings.autoplay));
}
function hydrateSettingsUI(){
  els.autoplayToggle.checked=!!state.settings.autoplay;
  els.speedSelect.value=String(state.settings.speed);
  els.reciterSelect.value=state.settings.reciter;
  els.textSizeSelect.value=state.settings.textSize || "standard";
  els.contrastToggle.checked=state.settings.highContrast !== false;
  applyAccessibilitySettings();
}

function applyAccessibilitySettings(){
  applyTheme();
  document.documentElement.dataset.textSize = state.settings.textSize || "standard";
  document.documentElement.dataset.highContrast = state.settings.highContrast === false ? "false" : "true";
  renderSettingSummary();
}
function makeFriendCode(){
  const alphabet="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let value="OQ-";
  const bytes=new Uint8Array(7);
  if(window.crypto?.getRandomValues) crypto.getRandomValues(bytes); else for(let i=0;i<bytes.length;i++) bytes[i]=Math.floor(Math.random()*256);
  for(const b of bytes) value+=alphabet[b%alphabet.length];
  return value;
}
function ensureFriendCode(){
  if(!state.profile.friendCode){ state.profile.friendCode=makeFriendCode(); saveState(); }
  return state.profile.friendCode;
}
function isPublicHostedUrl(){
  return ["http:","https:"].includes(window.location.protocol) && !["localhost","127.0.0.1","0.0.0.0"].includes(window.location.hostname);
}
function basePublicUrl(){
  if(!isPublicHostedUrl()) return "";
  const url=new URL(window.location.href); url.search=""; url.hash=""; return url.href;
}
function inviteUrl(){ return basePublicUrl(); }
async function reliableCopy(text){
  if(navigator.clipboard?.writeText && window.isSecureContext){
    try{ await navigator.clipboard.writeText(text); return true; }catch{}
  }
  const ta=document.createElement("textarea");
  ta.value=text; ta.setAttribute("readonly",""); ta.style.position="fixed"; ta.style.left="-9999px"; ta.style.top="0";
  document.body.appendChild(ta); ta.focus(); ta.select();
  let ok=false; try{ ok=document.execCommand("copy"); }catch{}
  ta.remove(); return ok;
}
let activeSharePayload={title:"OurQuran",text:"",url:""};
function openShareSheet(payload){
  activeSharePayload=payload;
  const hosted=!!payload.url;
  els.shareSheetTitle.textContent=payload.title;
  els.shareSheetDescription.textContent=payload.text;
  els.sharePreviewNotice.hidden=hosted;
  els.shareLinkLabel.textContent=hosted?payload.url:"Not hosted yet";
  els.copyShareLinkBtn.disabled=!hosted;
  const full=[payload.text,payload.url].filter(Boolean).join("\n");
  els.whatsappShareLink.href=`https://wa.me/?text=${encodeURIComponent(full)}`;
  els.emailShareLink.href=`mailto:?subject=${encodeURIComponent(payload.title)}&body=${encodeURIComponent(full)}`;
  els.nativeShareBtn.disabled=false;
  els.shareSheet.classList.add("open"); els.shareSheet.setAttribute("aria-hidden","false");
}
function closeShareSheet(){ els.shareSheet.classList.remove("open"); els.shareSheet.setAttribute("aria-hidden","true"); }
function shareSite(){
  openShareSheet({
    title:"Share OurQuran",
    text:"OurQuran — Read and ascend. Build a consistent Qur'an habit, track your reading, and use sourced daily adhkar.",
    url:inviteUrl()
  });
}
function consumeInviteFromUrl(){
  try{
    const url=new URL(window.location.href);
    if(url.searchParams.has("invite")||url.searchParams.has("from")){
      url.searchParams.delete("invite"); url.searchParams.delete("from");
      history.replaceState({},"",url.pathname+url.search+url.hash);
    }
  }catch{}
}
function addFriendLocal(handle){
  const raw=(handle||"").trim(); if(!raw) return showToast("Enter a username or friend code");
  const normalized=raw.replace(/^@/,"").slice(0,40);
  const exists=state.friends.some(f=>(f.handle||"").toLowerCase()===normalized.toLowerCase()||(f.code||"").toLowerCase()===normalized.toLowerCase());
  if(exists) return showToast("That friend is already on your list");
  state.friends.push({id:`f-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,displayName:normalized,handle:normalized,code:normalized.toUpperCase().startsWith("OQ-")?normalized.toUpperCase():"",status:"Pending • local prototype"});
  saveState(); renderFriends(); els.friendSearchInput.value=""; showToast("Friend added to the local prototype");
}
function acceptIncomingInvite(){
  const inv=state.incomingInvite; if(!inv) return;
  const exists=state.friends.some(f=>f.code===inv.code);
  if(!exists) state.friends.push({id:`f-${Date.now()}`,displayName:inv.displayName,handle:inv.displayName,code:inv.code,status:"Friend • local prototype"});
  state.incomingInvite=null; saveState(); renderFriends(); showToast(`${inv.displayName} added to your local friends`);
}
function rejectIncomingInvite(){ state.incomingInvite=null; saveState(); renderFriends(); }
function removeFriend(id){ state.friends=state.friends.filter(f=>f.id!==id); saveState(); renderFriends(); }
function renderFriends(){
  if(!els.friendsList) return;
  els.friendCodeDisplay.textContent=ensureFriendCode();
  if(state.incomingInvite){
    els.incomingInviteBox.hidden=false;
    els.incomingInviteBox.innerHTML=`<strong>${escapeHtml(state.incomingInvite.displayName)} invited you</strong><div class="incoming-invite-actions"><button class="soft-btn" data-accept-invite type="button">Accept</button><button class="soft-btn" data-reject-invite type="button">Dismiss</button></div>`;
  }else{ els.incomingInviteBox.hidden=true; els.incomingInviteBox.innerHTML=""; }
  if(!state.friends.length){ els.friendsList.innerHTML='<div class="empty-friends">No friends added yet. Share your invite link or add a username/friend code above.</div>'; return; }
  els.friendsList.innerHTML=state.friends.map(f=>`<div class="friend-row"><div class="friend-mini-avatar">${escapeHtml((f.displayName||"F")[0].toUpperCase())}</div><div class="friend-main"><strong>${escapeHtml(f.displayName||f.handle||"Friend")}</strong><span>${escapeHtml(f.code||('@'+(f.handle||'friend')))}</span></div><span class="friend-status">${escapeHtml(f.status||"Friend")}</span><button class="friend-remove" data-remove-friend="${escapeHtml(f.id)}" type="button" aria-label="Remove friend">×</button></div>`).join("");
}
function escapeHtml(value){ return String(value??"").replace(/[&<>'"]/g,ch=>({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"}[ch])); }

function setBottomNavActive(viewId=currentViewId){
  document.querySelectorAll(".bottom-nav-btn").forEach(btn=>{
    const isSettings=btn.dataset.navAction==="settings";
    const match=!isSettings && (btn.dataset.navView===viewId || (viewId==="readerView" && btn.dataset.navView==="dashboardView"));
    btn.classList.toggle("active",match);
  });
}
function openSettings(target=null){
  document.body.classList.add("drawer-open");
  els.settingsDrawer.classList.add("open");
  els.drawerOverlay.classList.add("open");
  els.settingsDrawer.setAttribute("aria-hidden","false");
  els.drawerOverlay.setAttribute("aria-hidden","false");
  document.querySelectorAll(".bottom-nav-btn").forEach(btn=>btn.classList.toggle("active",btn.dataset.navAction==="settings"));
  if(target){
    const map={reciter:"reciterSetting",speed:"speedSetting",autoplay:"autoplaySetting",text:"textSizeSetting"};
    const setting=document.getElementById(map[target]||target);
    if(setting){
      requestAnimationFrame(()=>{
        setting.scrollIntoView({behavior:"smooth",block:"center"});
        setting.classList.add("setting-highlight");
        setTimeout(()=>setting.classList.remove("setting-highlight"),1200);
        setting.querySelector("select,input,button")?.focus({preventScroll:true});
      });
    }
  }
}
function closeSettings(){
  document.body.classList.remove("drawer-open");
  els.settingsDrawer.classList.remove("open");
  els.drawerOverlay.classList.remove("open");
  els.settingsDrawer.setAttribute("aria-hidden","true");
  els.drawerOverlay.setAttribute("aria-hidden","true");
  setBottomNavActive();
}


function registerOurQuranServiceWorker(){
  if("serviceWorker" in navigator){
    navigator.serviceWorker.getRegistrations().then(regs=>regs.forEach(reg=>reg.unregister())).catch(()=>{});
  }
  if("caches" in window){
    caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith("ourquran-")).map(k=>caches.delete(k)))).catch(()=>{});
  }
}

async function init(){
  ensureHistoryDay();
  reconcileLegacyCalendarData();
  syncDerivedTotalsFromHistory();
  saveState();
  document.body.dataset.view="dashboardView";
  if(!state.profile.joinedAt){ state.profile.joinedAt=new Date().toISOString(); saveState(); }
  ensureFriendCode();
  consumeInviteFromUrl();
  applyAccessibilitySettings();
  populateReciters();
  hydrateSettingsUI();
  renderStats();
  renderSettingSummary();
  renderAdhkar();
  renderTasbeeh();
  renderNames();
  renderDashboard();
  renderProfile();
  setBottomNavActive("dashboardView");
  setSessionClock();
  try{
    surahs=await fetchJson(`${API}/surah`);
    populateSurahSelect();
    // The dashboard does not need to load a verse. Deferring verse loading until
    // the Reader opens prevents a stale startup/default position from racing a
    // signed-in Firestore hydration and overwriting the true resume point.
    renderHomeReaderCard();
  }catch(err){
    console.error(err);
    els.surahName.textContent="Could not load Qur'an data";
    els.translationText.textContent="Check your internet connection and refresh the page.";
    els.arabicText.textContent="تعذّر تحميل النص";
    els.prevBtn.disabled=true; els.nextBtn.disabled=true;
  }
}

const DISPLAY_BISMILLAH = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ";

function normalizeArabicBaseLetter(ch){
  if(/[ٱأإآ]/u.test(ch)) return "ا";
  return ch;
}
function splitOpeningBismillah(text,surahNumber,ayahNumber){
  const original=String(text||"");
  // Al-Fatihah 1:1 is the basmalah itself; At-Tawbah has no opening basmalah.
  if(Number(ayahNumber)!==1 || Number(surahNumber)===1 || Number(surahNumber)===9){
    return {bismillah:"",verseText:original};
  }
  const target="بسماللهالرحمنالرحيم";
  let built="";
  let boundary=-1;
  for(let i=0;i<original.length;i++){
    const ch=normalizeArabicBaseLetter(original[i]);
    if(/\p{Script=Arabic}/u.test(ch) && /\p{Letter}/u.test(ch)){
      built+=ch;
      if(!target.startsWith(built)) break;
      if(built===target){boundary=i+1;break;}
    }
  }
  if(boundary>0){
    while(boundary<original.length && /[\p{Mark}\s۝۞﴿﴾]/u.test(original[boundary])) boundary++;
    return {bismillah:original.slice(0,boundary).trim()||DISPLAY_BISMILLAH,verseText:original.slice(boundary).trim()};
  }
  // Some editions already keep it separate. We still render the opening
  // basmalah as its own line instead of gluing it to ayah 1.
  return {bismillah:DISPLAY_BISMILLAH,verseText:original};
}

async function loadSurah(surahNumber,targetAyah=1,autoplayAfterLoad=false){
  setLoading(true); stopAudio();
  const [arabic,english]=await Promise.all([
    fetchJson(`${API}/surah/${surahNumber}/quran-uthmani`),
    fetchJson(`${API}/surah/${surahNumber}/en.sahih`)
  ]);
  currentSurahArabic=arabic; currentSurahEnglish=english;
  state.surah=surahNumber; state.ayah=Math.max(1,Math.min(targetAyah,arabic.numberOfAyahs));
  currentSurahAudio=null; currentSurahAudioEdition=null; currentSurahAudioNumber=null;
  els.surahSelect.value=state.surah; populateAyahSelect(arabic.numberOfAyahs);
  renderAyah(); saveState(); setLoading(false);
  // Load the selected reciter's exact ayah URLs for this surah. Text remains
  // usable even if the audio metadata request is temporarily unavailable.
  await loadCurrentSurahAudio();
  if(autoplayAfterLoad&&state.settings.autoplay) playCurrentAudio(true);
}

function renderAyah(){
  const idx=state.ayah-1;
  currentAyah=currentSurahArabic.ayahs[idx]; currentTranslation=currentSurahEnglish.ayahs[idx];
  const opening=splitOpeningBismillah(currentAyah.text,state.surah,state.ayah);
  const visibleVerseText=opening.verseText || currentAyah.text;
  const letters=countArabicLetters(visibleVerseText); currentReward=letters*10;
  els.surahName.textContent=currentSurahArabic.englishName;
  els.surahEnglish.textContent=`${currentSurahArabic.name} • ${currentSurahArabic.englishNameTranslation}`;
  els.ayahNumber.textContent=state.ayah;
  if(els.bismillahText){
    els.bismillahText.textContent=opening.bismillah;
    els.bismillahText.hidden=!opening.bismillah;
  }
  els.arabicText.textContent=visibleVerseText;
  els.translationText.textContent=currentTranslation.text;
  els.gainPreview.textContent=formatNumber(currentReward);
  els.positionMeta.textContent=`${state.ayah} / ${currentSurahArabic.numberOfAyahs}`;
  els.juzMeta.textContent=`Juz ${currentAyah.juz}`;
  els.prevBtn.disabled=state.surah===1&&state.ayah===1;
  els.nextBtn.querySelector("strong").textContent=(state.surah===114&&state.ayah===currentSurahArabic.numberOfAyahs)?"Finish":"Next";
  els.ayahSelect.value=state.ayah;
  applyPlaybackPreferences();
  renderStats(); renderSettingSummary(); renderHomeReaderCard(); saveState();
}

function signedInTrackingActive(){
  return window.OURQURAN_SIGNED_IN === true || document.body.dataset.authState === "signed-in";
}

function renderStats(){
  const today=ensureHistoryDay();
  // Signed in: these values sync. Signed out: they are session-only and
  // account-sync deliberately never persists them.
  els.totalHasanaat.textContent=formatNumber(today.hasanaat);
  els.completedCount.textContent=formatNumber(today.ayat);
}

function historyActiveEntries(){
  return Object.entries(state.history)
    .map(([key,val])=>({key,date:dateFromKey(key),hasanaat:Number(val.hasanaat||0),ayat:Number(val.ayat||0)}))
    .filter(x=>x.ayat>0||x.hasanaat>0)
    .sort((a,b)=>a.date-b.date);
}
function bestDayRecord(){
  const rows=historyActiveEntries();
  if(!rows.length) return {hasanaat:0,ayat:0,key:null,date:null};
  return rows.reduce((best,row)=>row.hasanaat>best.hasanaat?row:best,rows[0]);
}
function streakMetrics(){
  const rows=historyActiveEntries();
  const active=new Set(rows.map(r=>r.key));
  let longest=0, run=0, previous=null;
  for(const row of rows){
    if(previous){ const expected=new Date(previous); expected.setDate(expected.getDate()+1); run=localDateKey(expected)===row.key?run+1:1; } else run=1;
    longest=Math.max(longest,run); previous=row.date;
  }
  let cursor=startOfDay(new Date());
  if(!active.has(localDateKey(cursor))){ cursor.setDate(cursor.getDate()-1); }
  let current=0;
  while(active.has(localDateKey(cursor))){ current++; cursor.setDate(cursor.getDate()-1); }
  return {current,longest,activeDays:rows.length};
}
function renderWeekHabit(now=new Date()){
  const start=startOfWeek(now); const todayKey=localDateKey(now); const days=[];
  for(let i=0;i<7;i++){ const d=new Date(start); d.setDate(start.getDate()+i); const key=localDateKey(d); const rec=state.history[key]||{ayat:0,hasanaat:0,seconds:0}; days.push({d,key,rec}); }
  els.weekHabitRow.innerHTML=days.map(({d,key,rec})=>{
    const active=Number(rec.ayat||0)>0, today=key===todayKey;
    const name=new Intl.DateTimeFormat(undefined,{weekday:"short"}).format(d).slice(0,2);
    return `<div class="habit-day ${active?'active':''} ${today?'today':''}" title="${formatDate(d,{weekday:'long',month:'short',day:'numeric'})}: ${rec.ayat||0} ayat • ${formatDuration(rec.seconds||0)}"><span class="day-name">${name}</span><span class="day-dot">${active?'✓':'○'}</span><span class="day-count">${rec.ayat||0} ayat</span></div>`;
  }).join("");
}
function renderGamification(today){
  const best=bestDayRecord(); const streak=streakMetrics();
  els.personalBest.textContent=formatNumber(best.hasanaat); if(els.profilePersonalBest) els.profilePersonalBest.textContent=formatNumber(best.hasanaat);
  const bestDate=best.date?formatDate(best.date,{month:"long",day:"numeric",year:"numeric"}):"No record yet";
  els.personalBestDate.textContent=best.date?`Set ${bestDate}`:"No record yet"; if(els.profileBestDate) els.profileBestDate.textContent=bestDate;
  els.prToday.textContent=formatNumber(today.hasanaat);
  const pct=best.hasanaat?Math.min(100,(today.hasanaat/best.hasanaat)*100):(today.hasanaat?100:0); els.prProgressFill.style.width=`${pct}%`;
  if(!best.hasanaat) els.prMessage.textContent="Your first reading day becomes the record.";
  else if(today.hasanaat===best.hasanaat && today.hasanaat>0) els.prMessage.textContent="Personal record day. One more ayah pushes it higher.";
  else if(today.hasanaat<best.hasanaat) els.prMessage.textContent=`${formatNumber(best.hasanaat-today.hasanaat)} hasanaat to tie your record.`;
  else els.prMessage.textContent="New personal record.";
  els.streakCurrent.textContent=streak.current; els.homeCurrentStreak.textContent=streak.current; els.streakLongest.textContent=streak.longest; els.activeDaysCount.textContent=streak.activeDays;
  if(els.profileCurrentStreak) els.profileCurrentStreak.textContent=streak.current; if(els.profileLongestStreak) els.profileLongestStreak.textContent=streak.longest; if(els.profileActiveDays) els.profileActiveDays.textContent=streak.activeDays;
}
const JUZ_STARTS = [
  [1,1],[2,142],[2,253],[3,93],[4,24],[4,148],[5,82],[6,111],[7,88],[8,41],
  [9,93],[11,6],[12,53],[15,1],[17,1],[18,75],[21,1],[23,1],[25,21],[27,56],
  [29,46],[33,31],[36,28],[39,32],[41,47],[46,1],[51,31],[58,1],[67,1],[78,1]
];
function juzForPosition(surahNumber,ayahNumber){
  const s=Math.max(1,Math.min(114,Number(surahNumber)||1));
  const a=Math.max(1,Number(ayahNumber)||1);
  let juz=1;
  for(let i=0;i<JUZ_STARTS.length;i++){
    const [js,ja]=JUZ_STARTS[i];
    if(s>js || (s===js && a>=ja)) juz=i+1;
    else break;
  }
  return juz;
}
function renderHomeReaderCard(){
  const surahNumber=Math.max(1,Math.min(114,Number(state.surah)||1));
  const ayahNumber=Math.max(1,Number(state.ayah)||1);
  const surah=surahs.find(s=>Number(s.number)===surahNumber);
  const surahLabel=surah?`${surahNumber}. ${surah.englishName}`:`Surah ${surahNumber}`;
  const juz=juzForPosition(surahNumber,ayahNumber);
  if(els.homeContinueSurah) els.homeContinueSurah.textContent=`Ayah ${ayahNumber} • ${surahLabel} • Juz ${juz}`;
}
function normalizedUsername(value){
  return String(value||"").toLowerCase().replace(/^@+/,"").replace(/[^a-z0-9_]/g,"").slice(0,20);
}
function renderAvatarElement(el, name){
  if(!el) return;
  const avatar=state.profile.avatarDataUrl||"";
  if(avatar){ el.style.backgroundImage=`url(${JSON.stringify(avatar).slice(1,-1)})`; el.textContent=""; }
  else { el.style.backgroundImage=""; el.textContent=(name[0]||"R").toUpperCase(); }
}
let profileEditorDirty=false;
function markProfileEditorDirty(){ profileEditorDirty=true; }
function markProfileEditorClean(){ profileEditorDirty=false; }
window.ourQuranProfileEditorCommit=markProfileEditorClean;

function renderProfile(){
  if(!els.profileNameDisplay) return;
  const username=normalizedUsername(state.profile.username)||"reader";
  const name=(state.profile.fullName||state.profile.displayName||username||"Reader").trim()||"Reader";
  const bio=(state.profile.bio||"").trim();
  els.profileNameDisplay.textContent=name;
  // Background Firebase saves refresh the profile often. Never overwrite text the
  // user is actively editing; only repopulate the editor after a confirmed save.
  if(!profileEditorDirty){
    if(els.profileFullNameInput) els.profileFullNameInput.value=(state.profile.fullName||"").trim();
    if(els.profileUsernameInput) els.profileUsernameInput.value=username;
    if(els.profileBioInput) els.profileBioInput.value=bio;
    if(els.profileBioCount) els.profileBioCount.textContent=String(bio.length);
  }
  if(els.profileHandleDisplay) els.profileHandleDisplay.textContent=`@${username}`;
  if(els.profileBioDisplay) els.profileBioDisplay.textContent=bio||"Add a short bio to your profile.";
  renderAvatarElement(els.profileAvatar,name);
  renderAvatarElement(els.profileAvatarEditPreview,name);
  if(els.homeGreetingName) els.homeGreetingName.textContent=name;
  const joined=state.profile.joinedAt?new Date(state.profile.joinedAt):new Date();
  els.profileJoined.textContent=`Local profile • joined ${formatDate(joined,{month:"long",year:"numeric"})}`;
  if(els.profileLifetime) els.profileLifetime.textContent=formatNumber(state.totalHasanaat); if(els.profileAyat) els.profileAyat.textContent=formatNumber(state.completedReads);
  const today=sumHistory(startOfDay(new Date()),endOfDay(new Date())); renderGamification(today);
  renderFriends();
}
function shareProgress(){
  const now=new Date();
  const today=sumHistory(startOfDay(now),endOfDay(now));
  const isGuest=document.body.dataset.authState!=="signed-in";

  if(isGuest){
    const text=`OurQuran — Read and ascend. Today: ${formatNumber(today.ayat)} ayat • ${formatNumber(today.hasanaat)} tracked hasanaat • ${formatDuration(today.seconds||0)} reading time.`;
    openShareSheet({
      mode:"progress",
      title:"Share today's progress",
      description:"Guest progress is today-only. Sign in to keep history across devices.",
      text,
      url:basePublicUrl()
    });
    return;
  }

  const streak=streakMetrics();
  const best=bestDayRecord();
  const text=`OurQuran — Read and ascend. Today: ${formatNumber(today.ayat)} ayat • ${formatNumber(today.hasanaat)} tracked hasanaat. Current streak: ${streak.current} day${streak.current===1?'':'s'}. Personal record: ${formatNumber(best.hasanaat)} in one day.`;
  openShareSheet({
    mode:"progress",
    title:"Share your progress",
    description:"Share today's reading and your current streak.",
    text,
    url:basePublicUrl()
  });
}
function saveProfileName(){
  if(window.OURQURAN_ACCOUNT?.saveProfile){
    window.OURQURAN_ACCOUNT.saveProfile();
    return;
  }

  const fullName=(els.profileFullNameInput?.value||state.profile.fullName||"").trim().slice(0,60);
  const username=normalizedUsername(els.profileUsernameInput?.value||state.profile.username||"");
  const bio=(els.profileBioInput?.value||"").trim().slice(0,120);

  if(!fullName){
    showToast("Enter your name");
    return;
  }
  if(username.length<3){
    showToast("Username must be at least 3 characters");
    return;
  }

  state.profile.fullName=fullName;
  state.profile.displayName=username;
  state.profile.username=username;
  state.profile.bio=bio;
  saveState();
  markProfileEditorClean();
  renderProfile();
  showToast("Profile saved");
}
function loadProfileAvatar(file){
  if(!file) return;
  if(!/^image\/(png|jpeg|webp)$/.test(file.type)) return showToast("Choose a PNG, JPG, or WebP image");
  if(file.size>8*1024*1024) return showToast("Choose an image under 8 MB");
  const url=URL.createObjectURL(file);
  const img=new Image();
  img.onload=()=>{
    try{
      const size=224, canvas=document.createElement("canvas"); canvas.width=size; canvas.height=size;
      const ctx=canvas.getContext("2d");
      const scale=Math.max(size/img.width,size/img.height);
      const w=img.width*scale,h=img.height*scale,x=(size-w)/2,y=(size-h)/2;
      ctx.fillStyle="#111"; ctx.fillRect(0,0,size,size); ctx.drawImage(img,x,y,w,h);
      state.profile.avatarDataUrl=canvas.toDataURL("image/webp",.78);
      saveState();
      if(window.OURQURAN_SIGNED_IN) setTimeout(()=>window.OURQURAN_ACCOUNT?.flush?.(),0);
      renderProfile(); showToast("Profile photo updated");
    }finally{ URL.revokeObjectURL(url); }
  };
  img.onerror=()=>{ URL.revokeObjectURL(url); showToast("Could not read that image"); };
  img.src=url;
}
function removeProfileAvatar(){ state.profile.avatarDataUrl=""; saveState(); if(window.OURQURAN_SIGNED_IN) setTimeout(()=>window.OURQURAN_ACCOUNT?.flush?.(),0); renderProfile(); showToast("Profile photo removed"); }

function renderDashboard(){
  ensureHistoryDay();
  syncDerivedTotalsFromHistory();
  const now=new Date();
  const dayStart=startOfDay(now), dayEnd=endOfDay(now);
  const weekStart=startOfWeek(now), weekEnd=endOfWeek(now);
  const monthStart=startOfMonth(now), monthEnd=endOfMonth(now);
  const tracked=signedInTrackingActive();
  const today=sumHistory(dayStart,dayEnd);
  const week=tracked?sumHistory(weekStart,weekEnd):today;
  const month=tracked?sumHistory(monthStart,monthEnd):today;

  els.dashAllTime.textContent=tracked?formatNumber(state.totalHasanaat):formatNumber(today.hasanaat);
  els.dashToday.textContent=formatNumber(today.hasanaat); els.dashTodayAyat.textContent=formatNumber(today.ayat);
  els.dashWeek.textContent=formatNumber(week.hasanaat); els.dashWeekAyat.textContent=formatNumber(week.ayat);
  els.dashMonth.textContent=formatNumber(month.hasanaat); els.dashMonthAyat.textContent=formatNumber(month.ayat);
  if(els.continueTodayHasanaat) els.continueTodayHasanaat.textContent=tracked?formatNumber(today.hasanaat):"0";
  if(els.continueWeekHasanaat) els.continueWeekHasanaat.textContent=tracked?formatNumber(week.hasanaat):"0";
  if(els.continueMonthHasanaat) els.continueMonthHasanaat.textContent=tracked?formatNumber(month.hasanaat):"0";
  els.todayRange.textContent=formatDate(now,{weekday:"long",month:"short",day:"numeric"});
  els.weekRange.textContent=`${formatDate(weekStart)} – ${formatDate(weekEnd)}`;
  els.monthRange.textContent=formatDate(now,{month:"long",year:"numeric"});
  renderTimeDisplays(now);
  renderWeeklyBars(now); renderWeekHabit(now); renderGamification(today); renderHomeReaderCard(today); renderDashboardAdhkar(); renderProfile();
}

function renderWeeklyBars(now=new Date()){
  const days=[];
  for(let i=6;i>=0;i--){ const d=startOfDay(now); d.setDate(d.getDate()-i); const key=localDateKey(d); const rec=state.history[key]||{hasanaat:0,ayat:0}; days.push({date:d,...rec}); }
  const max=Math.max(1,...days.map(d=>d.hasanaat));
  els.weeklyBars.innerHTML=days.map(d=>{
    const h=Math.max(d.hasanaat?6:2,(d.hasanaat/max)*100);
    const label=new Intl.DateTimeFormat(undefined,{weekday:"short"}).format(d.date);
    const val=d.hasanaat?formatNumber(d.hasanaat):"0";
    return `<div class="bar-day" title="${formatDate(d.date,{weekday:'long',month:'short',day:'numeric'})}: ${val} hasanaat"><div class="bar-track"><div class="bar-fill" style="height:${h}%"></div></div><div class="bar-value">${val}</div><div class="bar-label">${label}</div></div>`;
  }).join("");
}

function setLoading(loading){ els.prevBtn.disabled=loading; els.nextBtn.disabled=loading; els.surahSelect.disabled=loading; els.ayahSelect.disabled=loading; }
function commitCurrentAyah(){
  const day=ensureHistoryDay();
  day.hasanaat += currentReward;
  day.ayat += 1;
  sessionHasanaat += currentReward;
  sessionAyat += 1;
  syncDerivedTotalsFromHistory();
  saveState();
  renderStats();
  renderDashboard();
  showToast(signedInTrackingActive()?`+${formatNumber(currentReward)} hasanaat added`:`+${formatNumber(currentReward)} hasanaat • session only`);
}

function animateAyah(direction, updateFn){
  if(isTransitioning) return Promise.resolve(false);
  isTransitioning=true;
  const exitClass=direction==="next"?"exit-next":"exit-prev";
  const enterClass=direction==="next"?"enter-next":"enter-prev";
  return new Promise(resolve=>{
    els.ayahStage.classList.remove("exit-next","exit-prev","enter-next","enter-prev");
    void els.ayahStage.offsetWidth;
    els.ayahStage.classList.add(exitClass);
    setTimeout(async()=>{
      try{ await updateFn(); } finally {
        els.ayahStage.classList.remove(exitClass);
        els.ayahStage.classList.add(enterClass);
        setTimeout(()=>{ els.ayahStage.classList.remove(enterClass); isTransitioning=false; resolve(true); },290);
      }
    },170);
  });
}

async function goNext(){
  if(!currentAyah||isTransitioning) return;
  commitCurrentAyah(); stopAudio();
  if(state.ayah<currentSurahArabic.numberOfAyahs){
    await animateAyah("next",async()=>{ state.ayah+=1; renderAyah(); });
    syncReaderPositionSoon();
    if(state.settings.autoplay) playCurrentAudio(true);
    return;
  }
  if(state.surah<114){
    await animateAyah("next",async()=>{ await loadSurah(state.surah+1,1,false); });
    syncReaderPositionSoon();
    if(state.settings.autoplay) playCurrentAudio(true);
    return;
  }
  showToast("Qur'an completed — may Allah accept it.");
}

async function goPrevious(){
  if(isTransitioning) return; stopAudio();
  if(state.ayah>1){ await animateAyah("prev",async()=>{state.ayah-=1;renderAyah();}); syncReaderPositionSoon(); return; }
  if(state.surah>1){ const prev=surahs.find(s=>s.number===state.surah-1); await animateAyah("prev",async()=>{await loadSurah(state.surah-1,prev.numberOfAyahs,false);}); syncReaderPositionSoon(); }
}

let activeAudioCandidates = [];
let activeAudioCandidateIndex = 0;
let activeAudioKey = null;
let loadedAudioKey = null;

function currentAudioKey(){
  if(!currentAyah) return null;
  return `${Number(currentAyah.number)}:${state.settings.reciter}`;
}

function stopAudio(reset=true){
  const audio=els.audioPlayer;
  audio.pause();
  if(reset){
    try{ audio.currentTime=0; }catch{}
    // A paused HTMLAudioElement keeps its old src. If the user changes surah
    // and presses Play, that stale src can otherwise resume the previous verse.
    // Remove it completely so navigation can never replay an old ayah.
    try{
      audio.removeAttribute("src");
      audio.load();
    }catch{}
    activeAudioCandidates=[];
    activeAudioCandidateIndex=0;
    activeAudioKey=null;
    loadedAudioKey=null;
    delete audio.dataset.audioVerseKey;
    delete audio.dataset.audioGlobalAyah;
  }
  els.audioIcon.textContent="▶";
  els.audioLabel.textContent="Play";
  els.audioBtn?.setAttribute("aria-label","Play ayah audio");
}

function prepareAudioCandidates(force=false){
  if(!currentAyah) return false;
  const key=currentAudioKey();
  if(force || activeAudioKey!==key || !activeAudioCandidates.length){
    activeAudioKey=key;
    activeAudioCandidates=audioCandidatesForAyah();
    activeAudioCandidateIndex=0;
  }
  return activeAudioCandidates.length>0;
}

function loadAudioCandidate(index=0){
  if(!activeAudioCandidates.length || activeAudioKey!==currentAudioKey()) return false;
  activeAudioCandidateIndex = Math.max(0, Math.min(index, activeAudioCandidates.length-1));
  const candidate = activeAudioCandidates[activeAudioCandidateIndex];
  const audio = els.audioPlayer;

  // Refuse to load a candidate that is not explicitly for the visible ayah.
  const visibleVerseKey=`${Number(state.surah)}:${Number(state.ayah)}`;
  if(candidate.verseKey && candidate.verseKey!==visibleVerseKey) return false;

  audio.pause();
  audio.dataset.audioCandidate = String(activeAudioCandidateIndex);
  audio.dataset.audioProvider = candidate.provider || "";
  audio.dataset.audioReciter = state.settings.reciter;
  audio.dataset.audioVerseKey = visibleVerseKey;
  audio.dataset.audioGlobalAyah = String(Number(currentAyah?.number)||"");
  audio.src = candidate.url;
  loadedAudioKey=activeAudioKey;

  try{ audio.load(); }catch{}
  applyPlaybackPreferences();
  setTimeout(applyPlaybackPreferences, 0);
  setTimeout(applyPlaybackPreferences, 120);
  return true;
}

function playCurrentAudio(forceReload=false){
  if(!prepareAudioCandidates(forceReload)){
    showToast(`${currentReciter().name} audio is unavailable for this ayah.`);
    return;
  }
  const key=currentAudioKey();
  if(forceReload || !els.audioPlayer.src || loadedAudioKey!==key || els.audioPlayer.dataset.audioVerseKey!==`${state.surah}:${state.ayah}`){
    if(!loadAudioCandidate(0)) return;
  }
  applyPlaybackPreferences();

  els.audioPlayer.play().then(()=>{
    applyPlaybackPreferences();
    els.audioIcon.textContent="Ⅱ";
    els.audioLabel.textContent="Pause";
    els.audioBtn?.setAttribute("aria-label","Pause ayah audio");
  }).catch(err=>{
    if(err?.name === "NotAllowedError"){
      showToast("Your browser blocked autoplay. Press Play once to enable audio.");
      stopAudio(false);
    }else if(!els.audioPlayer.error){
      showToast("Audio could not start.");
      stopAudio(false);
    }
  });
}

function tryNextAudioCandidate(){
  // Ignore late error events from a media resource that belonged to the verse
  // the user just navigated away from.
  if(!activeAudioCandidates.length || activeAudioKey!==currentAudioKey()) return;
  const nextIndex = activeAudioCandidateIndex + 1;
  if(nextIndex >= activeAudioCandidates.length){
    stopAudio(false);
    showToast(`${currentReciter().name} is temporarily unavailable for this ayah.`);
    return;
  }

  if(!loadAudioCandidate(nextIndex)) return;
  const provider = activeAudioCandidates[nextIndex]?.provider || "backup source";
  showToast(`Trying ${provider}…`);
  els.audioPlayer.play().then(()=>{
    applyPlaybackPreferences();
    els.audioIcon.textContent="Ⅱ";
    els.audioLabel.textContent="Pause";
    els.audioBtn?.setAttribute("aria-label","Pause ayah audio");
  }).catch(()=>{});
}

function toggleAudio(){
  if(!currentAyah) return;
  const key=currentAudioKey();
  if(!prepareAudioCandidates(false)) return;
  if(!els.audioPlayer.src || loadedAudioKey!==key || els.audioPlayer.dataset.audioVerseKey!==`${state.surah}:${state.ayah}`){
    playCurrentAudio(true);
    return;
  }
  if(els.audioPlayer.paused){
    playCurrentAudio(false);
  }else{
    els.audioPlayer.pause();
    els.audioIcon.textContent="▶";
    els.audioLabel.textContent="Play";
    els.audioBtn?.setAttribute("aria-label","Play ayah audio");
  }
}


let activeAdhkarMode="morning";

function adhkarKey(mode=activeAdhkarMode,item=null){
  const scope=item?.sharedDaily?"daily":mode;
  return `${localDateKey(new Date())}|${scope}`;
}
function activeAdhkarItems(mode=activeAdhkarMode){ return ADHKAR.filter(item=>item.modes.includes(mode)); }
function ensureAdhkarBucket(mode=activeAdhkarMode,item=null){
  const key=adhkarKey(mode,item);
  if(!state.adhkarProgress[key]) state.adhkarProgress[key]={};
  return state.adhkarProgress[key];
}
function adhkarCount(item,mode=activeAdhkarMode){ return Math.min(item.target,Number(ensureAdhkarBucket(mode,item)[item.id]||0)); }
function completedAdhkarCount(mode){ return activeAdhkarItems(mode).filter(item=>adhkarCount(item,mode)>=item.target).length; }

function resolvedDhikrText(item,mode){
  const morning=mode==="morning";
  return {
    arabic: morning?(item.arabicMorning||item.arabic):(item.arabicEvening||item.arabic),
    translation: morning?(item.translationMorning||item.translation):(item.translationEvening||item.translation)
  };
}

function renderAdhkar(){
  const items=activeAdhkarItems();
  els.adhkarList.innerHTML=items.map(item=>{
    const count=adhkarCount(item,activeAdhkarMode), done=count>=item.target, text=resolvedDhikrText(item,activeAdhkarMode);
    const dailyBadge=item.sharedDaily?'<span class="timing-badge shared">Shared daily count</span>':'';
    return `<article class="dhikr-card ${done?'done':''}" data-dhikr-id="${item.id}">
      <div class="dhikr-card-head">
        <div><div class="dhikr-title">${item.title}</div><div class="dhikr-subtitle">${item.subtitle}</div><div class="dhikr-timing"><span class="timing-badge">${item.timing||''}</span>${dailyBadge}</div></div>
        <button class="dhikr-count-control ${done?'done':''}" type="button" data-count-dhikr="${item.id}">${done?'✓ Done':`${count} / ${item.target}`}</button>
      </div>
      <div class="dhikr-arabic" dir="rtl">${text.arabic.replace(/\n/g,'<br>')}</div>
      <div class="dhikr-translation">${text.translation}</div>
      <div class="dhikr-source"><a class="source-link" href="${item.url}" target="_blank" rel="noopener noreferrer">${item.source}</a><span class="source-grade">${item.grade}</span><span class="source-note">Verified source link</span></div>
    </article>`;
  }).join("");
  const done=completedAdhkarCount(activeAdhkarMode), total=items.length;
  els.adhkarDoneCount.textContent=done; els.adhkarTotalCount.textContent=total;
  els.adhkarProgressFill.style.width=`${total?(done/total)*100:0}%`;
  els.adhkarProgressLabel.textContent=`${activeAdhkarMode.toUpperCase()} PROGRESS`;
  document.querySelectorAll(".adhkar-mode").forEach(b=>b.classList.toggle("active",b.dataset.adhkarMode===activeAdhkarMode));
  renderDashboardAdhkar(); saveState();
}
function renderDashboardAdhkar(){
  const morning=activeAdhkarItems("morning"), evening=activeAdhkarItems("evening");
  if(els.dashMorningDone){els.dashMorningDone.textContent=completedAdhkarCount("morning");els.dashMorningTotal.textContent=morning.length;}
  if(els.dashEveningDone){els.dashEveningDone.textContent=completedAdhkarCount("evening");els.dashEveningTotal.textContent=evening.length;}
}
function incrementDhikr(id){
  const item=ADHKAR.find(x=>x.id===id); if(!item)return;
  const bucket=ensureAdhkarBucket(activeAdhkarMode,item), current=Number(bucket[id]||0);
  bucket[id]=Math.min(item.target,current+1); saveState(); renderAdhkar();
  if(bucket[id]>=item.target) showToast(`${item.title} complete`);
}
function setAdhkarMode(mode){activeAdhkarMode=mode;renderAdhkar();}
function resetAdhkarMode(){
  if(!confirm(`Reset today's ${activeAdhkarMode} adhkar checklist?`)) return;
  activeAdhkarItems(activeAdhkarMode).forEach(item=>{ const bucket=ensureAdhkarBucket(activeAdhkarMode,item); delete bucket[item.id]; });
  saveState();renderAdhkar();showToast(`${activeAdhkarMode[0].toUpperCase()+activeAdhkarMode.slice(1)} checklist reset`);
}

function renderTasbeeh(){
  const target=Math.max(1,Number(state.tasbeeh.target)||33), count=Math.max(0,Number(state.tasbeeh.count)||0);
  els.tasbeehPreset.value=state.tasbeeh.phrase;
  els.tasbeehTarget.value=target;
  els.tasbeehPhrase.textContent=state.tasbeeh.phrase;
  els.tasbeehCount.textContent=formatNumber(count);
  els.tasbeehTargetLabel.textContent=formatNumber(target);
  els.tasbeehRemaining.textContent=count>=target?"Target reached":`${formatNumber(target-count)} remaining`;
  els.tasbeehMeterFill.style.width=`${Math.min(100,(count/target)*100)}%`;
}
function incrementTasbeeh(){
  state.tasbeeh.count=Number(state.tasbeeh.count||0)+1; saveState(); renderTasbeeh();
  if(state.tasbeeh.count===Number(state.tasbeeh.target)) showToast("Tasbeeh target reached");
}
function resetTasbeeh(){ state.tasbeeh.count=0; saveState(); renderTasbeeh(); }

function renderNames(filter=""){
  const q=filter.trim().toLowerCase();
  const rows=ALLAH_NAMES.map((n,i)=>({n,i})).filter(({n})=>!q||n.join(" ").toLowerCase().includes(q));
  els.namesGrid.innerHTML=rows.map(({n,i})=>`<article class="name-card"><span class="name-number">${String(i+1).padStart(2,'0')}</span><div class="name-arabic">${n[0]}</div><div class="name-translit">${n[1]}</div><div class="name-meaning">${n[2]}</div></article>`).join("");
  els.visibleNamesCount.textContent=rows.length;
}


function setSessionClock(){
  // Local-only Reader session timer. It survives a refresh, never enters Firebase,
  // and only advances while the Reader view is actually visible in the foreground.
  const SESSION_KEY="ourQuranReaderSessionV48";
  const SESSION_IDLE_RESET_MS=30*60*1000;
  const MAX_SAMPLE_MS=2500;

  const readStored=()=>{
    try{
      const raw=JSON.parse(localStorage.getItem(SESSION_KEY)||"null")||{};
      return {
        seconds:Math.max(0,Math.floor(Number(raw.seconds||0))),
        lastReadingAt:Math.max(0,Number(raw.lastReadingAt||0))
      };
    }catch{return {seconds:0,lastReadingAt:0};}
  };

  let session=readStored();
  const bootAt=Date.now();
  if(session.lastReadingAt && bootAt-session.lastReadingAt>SESSION_IDLE_RESET_MS){
    session={seconds:0,lastReadingAt:0};
  }

  let lastSampleAt=bootAt;
  let carryMs=0;

  const persist=()=>{
    try{localStorage.setItem(SESSION_KEY,JSON.stringify(session));}catch{}
  };
  const render=()=>{
    if(els.sessionTime)els.sessionTime.textContent=formatDuration(session.seconds);
  };
  const readerIsActive=()=>document.visibilityState==="visible"&&currentViewId==="readerView";

  function accrue(now=Date.now()){
    const elapsed=Math.max(0,now-lastSampleAt);
    lastSampleAt=now;

    if(!readerIsActive()){
      carryMs=0;
      return;
    }

    if(session.lastReadingAt && now-session.lastReadingAt>SESSION_IDLE_RESET_MS){
      session.seconds=0;
      carryMs=0;
    }

    const safeMs=Math.min(elapsed,MAX_SAMPLE_MS);
    carryMs+=safeMs;
    const whole=Math.floor(carryMs/1000);
    if(whole>0){
      carryMs-=whole*1000;
      session.seconds+=whole;
      session.lastReadingAt=now;
      persist();
      render();
    }else if(!session.lastReadingAt){
      session.lastReadingAt=now;
      persist();
    }
  }

  // Account sync may call this before a cloud write. It only flushes the local
  // session clock; no seconds are added to reading history or Firestore.
  window.ourQuranCommitActiveTime=()=>{
    accrue(Date.now());
    persist();
    render();
  };
  window.ourQuranRenderLocalSession=render;

  // Auth changes must not reset a local session timer.
  window.ourQuranResetTrackingClock=()=>{
    lastSampleAt=Date.now();
    carryMs=0;
    render();
  };

  window.ourQuranResetLocalSession=()=>{
    session={seconds:0,lastReadingAt:0};
    lastSampleAt=Date.now();
    carryMs=0;
    try{localStorage.removeItem(SESSION_KEY);}catch{}
    render();
  };

  setInterval(()=>accrue(Date.now()),1000);
  document.addEventListener("visibilitychange",()=>{
    accrue(Date.now());
    if(document.visibilityState==="visible"){
      lastSampleAt=Date.now();
      carryMs=0;
    }
    persist();
    render();
  });
  window.addEventListener("pagehide",()=>{accrue(Date.now());persist();});
  window.addEventListener("beforeunload",()=>{accrue(Date.now());persist();});

  render();
}


function validPublicUrl(value){
  try{
    const url = new URL(String(value || ""));
    return url.protocol === "https:";
  }catch{return false;}
}

function openUtilityModal(kind){
  const isSupport = kind === "support";
  const modal = isSupport ? els.supportModal : els.feedbackModal;
  if(!modal) return;

  if(isSupport){
    const configured = validPublicUrl(SITE_CONFIG.supportUrl);
    els.supportSetupNotice.hidden = configured;
    els.supportPaymentLink.hidden = !configured;
    if(configured) els.supportPaymentLink.href = SITE_CONFIG.supportUrl;
  }else{
    els.feedbackName.value = (state.profile.fullName||"").trim();
    els.feedbackStatus.textContent = "";
    els.feedbackCharCount.textContent = String(els.feedbackMessage.value.length);
    if(els.feedbackViewField) els.feedbackViewField.value = currentViewId;
    if(els.feedbackThemeField) els.feedbackThemeField.value = state.settings.theme;
    if(els.feedbackVersionField) els.feedbackVersionField.value = "V49";
    if(els.feedbackSubmittedAtField) els.feedbackSubmittedAtField.value = "";
  }

  modal.classList.add("open");
  modal.setAttribute("aria-hidden","false");
  document.body.classList.add("utility-modal-open");
}

function closeUtilityModal(kind){
  const modal = kind === "support" ? els.supportModal : els.feedbackModal;
  if(!modal) return;
  modal.classList.remove("open");
  modal.setAttribute("aria-hidden","true");
  if(!document.querySelector(".utility-modal.open")) document.body.classList.remove("utility-modal-open");
}

async function submitFeedback(event){
  event.preventDefault();

  const message = els.feedbackMessage.value.trim();
  if(!message){
    els.feedbackStatus.textContent = "Please write a message first.";
    return;
  }

  const submit = els.submitFeedbackBtn;
  submit.disabled = true;
  els.feedbackStatus.textContent = "Sending…";

  if(els.feedbackViewField) els.feedbackViewField.value = currentViewId;
  if(els.feedbackThemeField) els.feedbackThemeField.value = state.settings.theme;
  if(els.feedbackVersionField) els.feedbackVersionField.value = "V49";
  if(els.feedbackSubmittedAtField) els.feedbackSubmittedAtField.value = new Date().toISOString();

  try{
    // Netlify detects this form at deploy time via data-netlify="true".
    // AJAX submissions must be URL-encoded and include form-name.
    const formData = new FormData(els.feedbackForm);
    const encoded = new URLSearchParams();
    for(const [key,value] of formData.entries()){
      encoded.append(key, String(value));
    }

    const response = await fetch("/",{
      method:"POST",
      headers:{"Content-Type":"application/x-www-form-urlencoded;charset=UTF-8"},
      body:encoded.toString()
    });

    if(!response.ok){
      throw new Error(`Netlify Forms submission failed: ${response.status}`);
    }

    els.feedbackStatus.textContent = "Thank you — your feedback was sent.";
    els.feedbackMessage.value = "";
    els.feedbackCharCount.textContent = "0";
    if(els.feedbackSubmittedAtField) els.feedbackSubmittedAtField.value = "";

    setTimeout(()=>closeUtilityModal("feedback"),900);
  }catch(err){
    console.error(err);
    els.feedbackStatus.textContent = navigator.onLine
      ? "Could not send feedback. Please try again."
      : "You're offline. Reconnect and try again.";
  }finally{
    submit.disabled = false;
  }
}

function syncReaderPositionSoon(){
  // saveState already marks the signed-in account dirty. An eager flush makes
  // Surah/Ayah changes durable across devices without waiting for the normal
  // autosave delay. Firestore's transaction merge still protects newer data.
  saveState();
  if(window.OURQURAN_SIGNED_IN){
    setTimeout(()=>window.OURQURAN_ACCOUNT?.flush?.(),80);
  }
}

async function openReaderAtSavedPosition(){
  const targetSurah=Math.max(1,Math.min(114,Number(state.surah)||1));
  const targetAyah=Math.max(1,Number(state.ayah)||1);

  // Open the reader immediately, then explicitly load the exact persisted
  // position. This avoids showing a stale Al-Fatihah render left over from
  // startup while Firebase/local state says the user stopped elsewhere.
  switchView("readerView");
  try{
    if(!surahs.length){
      surahs=await fetchJson(`${API}/surah`);
      populateSurahSelect();
    }
    await loadSurah(targetSurah,targetAyah,false);
  }catch(err){
    console.error("Could not resume saved Qur'an position",err);
    showToast("Could not load your saved reading position");
  }
}

function switchView(id){
  const previousView=currentViewId;

  // A mobile tab change must never happen behind an open settings drawer.
  // Closing it first also releases body.drawer-open so page scrolling cannot stay locked.
  if(document.body.classList.contains("drawer-open")) closeSettings();

  // Audio belongs to the Reader. Leaving the Reader must stop it immediately,
  // whether the user taps "I'm Done", Home, Profile, Settings navigation, etc.
  if(previousView==="readerView" && id!=="readerView"){
    stopAudio(true);
  }

  currentViewId=id;
  document.body.dataset.view=id;
  document.querySelectorAll(".view").forEach(v=>{ const active=v.id===id; v.hidden=!active; v.classList.toggle("active-view",active); });
  setBottomNavActive(id);
  if(id==="dashboardView") renderDashboard();
  if(id==="profileView") renderProfile();
  if(id==="adhkarView"){ renderAdhkar(); renderTasbeeh(); }
  if(id==="namesView") renderNames(els.namesSearch?.value||"");
  window.scrollTo({top:0,left:0,behavior:window.matchMedia("(max-width: 820px)").matches?"auto":"smooth"});
}

document.querySelectorAll("[data-nav-view]").forEach(btn=>btn.addEventListener("click",()=>switchView(btn.dataset.navView)));
document.querySelectorAll("[data-nav-action='settings']").forEach(btn=>btn.addEventListener("click",()=>openSettings()));
document.getElementById("settingsContinueReadingBtn")?.addEventListener("click",()=>{ closeSettings(); openReaderAtSavedPosition(); });
els.nextBtn.addEventListener("click",goNext);
els.prevBtn.addEventListener("click",goPrevious);
els.audioBtn.addEventListener("click",toggleAudio);
els.audioPlayer.addEventListener("ended",()=>stopAudio(false));
els.audioPlayer.addEventListener("error",tryNextAudioCandidate);
els.audioPlayer.addEventListener("loadstart",applyPlaybackPreferences);
els.audioPlayer.addEventListener("loadedmetadata",applyPlaybackPreferences);
els.audioPlayer.addEventListener("loadeddata",applyPlaybackPreferences);
els.audioPlayer.addEventListener("canplay",applyPlaybackPreferences);
els.audioPlayer.addEventListener("play",applyPlaybackPreferences);
els.audioPlayer.addEventListener("playing",applyPlaybackPreferences);
els.audioPlayer.addEventListener("ratechange",()=>{
  const target=requestedPlaybackRate();
  if(Math.abs(Number(els.audioPlayer.playbackRate||1)-target)>0.0001){
    applyPlaybackPreferences();
  }
});
els.surahSelect.addEventListener("change",async e=>{ stopAudio(); await animateAyah("next",async()=>{await loadSurah(Number(e.target.value),1,false);}); syncReaderPositionSoon(); });
els.ayahSelect.addEventListener("change",async e=>{ const target=Number(e.target.value); const direction=target>=state.ayah?"next":"prev"; stopAudio(); await animateAyah(direction,async()=>{state.ayah=target;renderAyah();}); syncReaderPositionSoon(); });
els.closeSettingsBtn.addEventListener("click",closeSettings); els.drawerOverlay.addEventListener("click",closeSettings);
els.autoplayToggle.addEventListener("change",e=>{state.settings.autoplay=e.target.checked;saveState();renderSettingSummary();showToast(`Autoplay ${state.settings.autoplay?'enabled':'disabled'}`);});
els.speedSelect.addEventListener("change",e=>{
  state.settings.speed=Number(e.target.value);
  applyPlaybackPreferences();
  // Apply again on the next task so a just-loaded media element cannot
  // overwrite the selected rate.
  setTimeout(applyPlaybackPreferences,0);
  setTimeout(applyPlaybackPreferences,120);
  saveState();
  renderSettingSummary();
  showToast(`Speed set to ${requestedPlaybackRate()}×`);
});

els.reciterSelect.addEventListener("change",async e=>{
  const wasPlaying = !els.audioPlayer.paused && !els.audioPlayer.ended;
  state.settings.reciter=e.target.value;
  stopAudio(true);
  currentSurahAudio=null; currentSurahAudioEdition=null; currentSurahAudioNumber=null;
  saveState();
  renderSettingSummary();
  showToast(`Reciter changed to ${currentReciter().name}`);
  await loadCurrentSurahAudio();
  if(wasPlaying) playCurrentAudio(true);
});
document.querySelectorAll("[data-setting-target]").forEach(btn=>btn.addEventListener("click",()=>openSettings(btn.dataset.settingTarget)));
els.autoplayQuickBtn?.addEventListener("click",()=>{
  state.settings.autoplay=!state.settings.autoplay;
  els.autoplayToggle.checked=state.settings.autoplay;
  saveState(); renderSettingSummary();
  showToast(`Autoplay ${state.settings.autoplay?"on":"off"}`);
});

document.querySelectorAll("[data-theme-option]").forEach(btn=>btn.addEventListener("click",()=>{
  state.settings.theme = btn.dataset.themeOption;
  saveState();
  applyTheme();
  showToast(`${btn.textContent.trim()} theme`);
}));

function closeQuickThemeMenu(){
  if(!els.quickThemePopover || !els.quickThemeButton) return;
  els.quickThemePopover.hidden=true;
  els.quickThemeButton.setAttribute("aria-expanded","false");
}

els.quickThemeButton?.addEventListener("click",e=>{
  e.stopPropagation();
  const willOpen=els.quickThemePopover.hidden;
  els.quickThemePopover.hidden=!willOpen;
  els.quickThemeButton.setAttribute("aria-expanded",String(willOpen));
});

document.querySelectorAll("[data-quick-theme]").forEach(btn=>btn.addEventListener("click",()=>{
  const theme=btn.dataset.quickTheme;
  if(!["kaaba","sunset","dark","light"].includes(theme)) return;
  state.settings.theme=theme;
  saveState();
  applyTheme();
  closeQuickThemeMenu();
  showToast(`${btn.textContent.replace("✓","").trim()} theme`);
}));

document.addEventListener("click",e=>{
  if(!e.target.closest(".quick-theme-menu")) closeQuickThemeMenu();
});

document.addEventListener("keydown",e=>{
  if(e.key==="Escape") closeQuickThemeMenu();
});

els.resetBtn.addEventListener("click",async()=>{if(!confirm("Reset all local OurQuran progress, history, totals, and settings?"))return;localStorage.removeItem(STORAGE_KEY);window.ourQuranResetLocalSession?.();state=deepDefaultState();sessionHasanaat=0;sessionAyat=0;ensureHistoryDay();syncDerivedTotalsFromHistory();populateReciters();hydrateSettingsUI();renderStats();renderDashboard();renderProfile();renderSettingSummary();closeSettings();await loadSurah(1,1,false);showToast("Local data reset");});


document.querySelectorAll(".adhkar-mode").forEach(btn=>btn.addEventListener("click",()=>setAdhkarMode(btn.dataset.adhkarMode)));
els.adhkarList?.addEventListener("click",e=>{ const btn=e.target.closest("[data-count-dhikr]"); if(btn) incrementDhikr(btn.dataset.countDhikr); });
els.resetAdhkarBtn?.addEventListener("click",resetAdhkarMode);
document.querySelectorAll("[data-open-adhkar]").forEach(btn=>btn.addEventListener("click",()=>{activeAdhkarMode=btn.dataset.openAdhkar;switchView("adhkarView");}));
document.getElementById("doneBtn")?.addEventListener("click",()=>{
  // Capture the exact last reading position/time before returning Home.
  stopAudio(true);
  window.ourQuranCommitActiveTime?.();
  saveState();
},{capture:true});

document.querySelectorAll("[data-open-view]").forEach(btn=>btn.addEventListener("click",()=>btn.dataset.openView==="readerView"?openReaderAtSavedPosition():switchView(btn.dataset.openView)));
document.querySelectorAll(".clickable-tool-card").forEach(card=>card.addEventListener("keydown",e=>{ if(e.key!=="Enter"&&e.key!==" ") return; e.preventDefault(); card.click(); }));
els.tasbeehButton?.addEventListener("click",incrementTasbeeh);
els.tasbeehReset?.addEventListener("click",resetTasbeeh);
els.tasbeehPreset?.addEventListener("change",e=>{state.tasbeeh.phrase=e.target.value;state.tasbeeh.count=0;saveState();renderTasbeeh();});
els.tasbeehTarget?.addEventListener("change",e=>{state.tasbeeh.target=Math.max(1,Math.min(10000,Number(e.target.value)||33));saveState();renderTasbeeh();});
els.namesSearch?.addEventListener("input",e=>renderNames(e.target.value));
els.continueReadingBtn?.addEventListener("click",()=>openReaderAtSavedPosition());
els.shareHomeBtn?.addEventListener("click",shareProgress); els.shareProfileBtn?.addEventListener("click",shareProgress);
els.shareSiteHomeBtn?.addEventListener("click",shareSite); els.shareSiteProfileBtn?.addEventListener("click",shareSite); els.inviteFriendsBtn?.addEventListener("click",shareSite);
els.copyFriendCodeBtn?.addEventListener("click",async()=>{ const code=ensureFriendCode(); try{await navigator.clipboard.writeText(code);showToast("Friend code copied");}catch{showToast(code);} });
els.addFriendBtn?.addEventListener("click",()=>addFriendLocal(els.friendSearchInput.value));
els.friendSearchInput?.addEventListener("keydown",e=>{if(e.key==="Enter") addFriendLocal(els.friendSearchInput.value);});
els.incomingInviteBox?.addEventListener("click",e=>{if(e.target.closest("[data-accept-invite]"))acceptIncomingInvite();if(e.target.closest("[data-reject-invite]"))rejectIncomingInvite();});
els.friendsList?.addEventListener("click",e=>{const btn=e.target.closest("[data-remove-friend]");if(btn)removeFriend(btn.dataset.removeFriend);});
els.saveProfileNameBtn?.addEventListener("click",saveProfileName);
els.profileFullNameInput?.addEventListener("input",markProfileEditorDirty);
els.profileFullNameInput?.addEventListener("keydown",e=>{ if(e.key==="Enter") saveProfileName(); });
els.profileUsernameInput?.addEventListener("input",e=>{ markProfileEditorDirty(); e.target.value=normalizedUsername(e.target.value); });
els.profileUsernameInput?.addEventListener("keydown",e=>{ if(e.key==="Enter") saveProfileName(); });
els.profileBioInput?.addEventListener("input",e=>{ markProfileEditorDirty(); if(els.profileBioCount) els.profileBioCount.textContent=String(e.target.value.length); });
els.profileAvatarButton?.addEventListener("click",()=>els.profileAvatarInput?.click());
els.profileAvatarInput?.addEventListener("change",e=>{ loadProfileAvatar(e.target.files?.[0]); e.target.value=""; });
els.removeProfileAvatarBtn?.addEventListener("click",removeProfileAvatar);
els.railSurahBtn?.addEventListener("click",()=>{ els.surahSelect?.focus(); els.surahFloatingControl?.scrollIntoView({block:"nearest",behavior:"smooth"}); });
els.railAyahBtn?.addEventListener("click",()=>{ els.ayahSelect?.focus(); els.ayahFloatingControl?.scrollIntoView({block:"nearest",behavior:"smooth"}); });
els.railInfoBtn?.addEventListener("click",()=>els.readerFloatingMeta?.scrollIntoView({block:"nearest",behavior:"smooth"}));
els.closeShareSheetBtn?.addEventListener("click",closeShareSheet);
els.shareSheetOverlay?.addEventListener("click",closeShareSheet);
els.nativeShareBtn?.addEventListener("click",async()=>{
  if(typeof navigator.share!=="function"){
    const text=[activeSharePayload.text,activeSharePayload.url].filter(Boolean).join("\n");
    const ok=await reliableCopy(text);
    return showToast(ok?"Share message copied":"Could not open sharing — use Copy message below");
  }
  try{ await navigator.share(activeSharePayload); closeShareSheet(); }catch(err){ if(err?.name!=="AbortError") showToast("Could not open the share menu"); }
});
els.copyShareTextBtn?.addEventListener("click",async()=>{
  const text=[activeSharePayload.text,activeSharePayload.url].filter(Boolean).join("\n");
  const ok=await reliableCopy(text); showToast(ok?"Share message copied":"Select and copy the message manually");
});
els.copyShareLinkBtn?.addEventListener("click",async()=>{
  if(!activeSharePayload.url) return showToast("A public link will be available after hosting");
  const ok=await reliableCopy(activeSharePayload.url); showToast(ok?"Public link copied":"Could not copy the link");
});
els.whatsappShareLink?.addEventListener("click",e=>{
  e.preventDefault();
  const href=els.whatsappShareLink.href;
  const opened=window.open(href,"_blank","noopener,noreferrer");
  if(!opened) window.location.href=href;
});
els.emailShareLink?.addEventListener("click",e=>{
  e.preventDefault();
  window.location.href=els.emailShareLink.href;
});


els.supportBtn?.addEventListener("click",()=>openUtilityModal("support"));
els.feedbackBtn?.addEventListener("click",()=>openUtilityModal("feedback"));
els.closeSupportBtn?.addEventListener("click",()=>closeUtilityModal("support"));
els.closeFeedbackBtn?.addEventListener("click",()=>closeUtilityModal("feedback"));
document.querySelectorAll("[data-close-utility='support']").forEach(el=>el.addEventListener("click",()=>closeUtilityModal("support")));
document.querySelectorAll("[data-close-utility='feedback']").forEach(el=>el.addEventListener("click",()=>closeUtilityModal("feedback")));
els.feedbackMessage?.addEventListener("input",()=>{els.feedbackCharCount.textContent=String(els.feedbackMessage.value.length);});
els.feedbackForm?.addEventListener("submit",submitFeedback);

document.addEventListener("keydown",e=>{
  if(e.key==="Escape"&&els.supportModal?.classList.contains("open")){closeUtilityModal("support");return;}
  if(e.key==="Escape"&&els.feedbackModal?.classList.contains("open")){closeUtilityModal("feedback");return;}
  if(e.key==="Escape"&&els.shareSheet?.classList.contains("open")){closeShareSheet();return;}
  if(e.key==="Escape"&&els.settingsDrawer.classList.contains("open")){closeSettings();return;}
  if(els.settingsDrawer.classList.contains("open"))return;
  if(e.target.matches("select,input,textarea"))return;
  if(e.key==="ArrowRight")goNext(); if(e.key==="ArrowLeft")goPrevious(); if(e.code==="Space"){e.preventDefault();toggleAudio();}
});

window.addEventListener("storage",e=>{
  if(e.key!==STORAGE_KEY || !e.newValue) return;
  state=loadState();
  hydrateSettingsUI(); renderStats(); renderSettingSummary();
  if(currentViewId==="dashboardView") renderDashboard();
  if(currentViewId==="profileView") renderProfile();
});

registerOurQuranServiceWorker();
init();

els.textSizeSelect?.addEventListener("change",e=>{ state.settings.textSize=e.target.value; saveState(); applyAccessibilitySettings(); showToast(`Reading text: ${els.currentTextSizeLabel?.textContent||"Standard"}`); });
els.textSizeQuickBtn?.addEventListener("click",()=>{
  const sizes=["standard","large","xlarge"];
  const next=sizes[(sizes.indexOf(state.settings.textSize)+1)%sizes.length];
  state.settings.textSize=next;
  els.textSizeSelect.value=next;
  saveState(); applyAccessibilitySettings();
  showToast(`Reading text: ${els.currentTextSizeLabel.textContent}`);
});
els.contrastToggle?.addEventListener("change",e=>{ state.settings.highContrast=e.target.checked; saveState(); applyAccessibilitySettings(); });
