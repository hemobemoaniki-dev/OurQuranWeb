/* OurQuran public configuration. Firebase web config is safe to expose in client code.
   Security comes from Firebase Authentication + Firestore Security Rules. */
window.OURQURAN_CONFIG = {
  supportUrl: "https://ko-fi.com/ourquran",
  publicSiteUrl: "https://ourquran.netlify.app/",

  // Firebase Console -> Project settings -> Your apps -> Web app -> SDK setup and configuration
  firebase: {
    apiKey: "AIzaSyBvVJLvPotrhBB4NLhWn4d-pHc1mxew_T0",
    authDomain: "ourquran.firebaseapp.com",
    projectId: "ourquran",
    storageBucket: "ourquran.firebasestorage.app",
    messagingSenderId: "354539547523",
    appId: "1:354539547523:web:5d49713b3033087c9a64b6"
  }
};
